<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * This file contains the forms to create and edit an instance of this module
 *
 * @package   mod_assignjava
 * @copyright 2012 NetSpot {@link http://www.netspot.com.au}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die('Direct access to this script is forbidden.');


require_once($CFG->libdir.'/formslib.php');
require_once($CFG->dirroot . '/mod/assignjava/locallib.php');

/**
 * Assignment grading options form
 *
 * @package   mod_assignjava
 * @copyright 2012 NetSpot {@link http://www.netspot.com.au}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mod_assignjava_grading_options_form extends moodleform {
    /**
     * Define this form - called from the parent constructor.
     */
    public function definition() {
        $mform = $this->_form;
        $instance = $this->_customdata;
        $dirtyclass = array('class'=>'ignoredirty');

        $mform->addElement('header', 'general', get_string('gradingoptions', 'assignjava'));
        // Visible elements.
        $options = array(-1=>get_string('all'), 10=>'10', 20=>'20', 50=>'50', 100=>'100');
        $mform->addElement('select', 'perpage', get_string('assignmentsperpage', 'assignjava'), $options, $dirtyclass);
        $options = array('' => get_string('filternone', 'assignjava'),
                         ASSIGNJAVA_FILTER_NOT_SUBMITTED => get_string('filternotsubmitted', 'assignjava'),
                         ASSIGNJAVA_FILTER_SUBMITTED => get_string('filtersubmitted', 'assignjava'),
                         ASSIGNJAVA_FILTER_REQUIRE_GRADING => get_string('filterrequiregrading', 'assignjava'));
        if ($instance['submissionsenabled']) {
            $mform->addElement('select', 'filter', get_string('filter', 'assignjava'), $options, $dirtyclass);
        }
        if (!empty($instance['markingallocationopt'])) {
            $markingfilter = get_string('markerfilter', 'assignjava');
            $mform->addElement('select', 'markerfilter', $markingfilter, $instance['markingallocationopt'], $dirtyclass);
        }
        if (!empty($instance['markingworkflowopt'])) {
            $workflowfilter = get_string('workflowfilter', 'assignjava');
            $mform->addElement('select', 'workflowfilter', $workflowfilter, $instance['markingworkflowopt'], $dirtyclass);
        }
        // Quickgrading.
        if ($instance['showquickgrading']) {
            $mform->addElement('checkbox', 'quickgrading', get_string('quickgrading', 'assignjava'), '', $dirtyclass);
            $mform->addHelpButton('quickgrading', 'quickgrading', 'assignjava');
            $mform->setDefault('quickgrading', $instance['quickgrading']);
        }

        // Show active/suspended user option.
        if ($instance['showonlyactiveenrolopt']) {
            $mform->addElement('checkbox', 'showonlyactiveenrol', get_string('showonlyactiveenrol', 'grades'), '', $dirtyclass);
            $mform->addHelpButton('showonlyactiveenrol', 'showonlyactiveenrol', 'grades');
            $mform->setDefault('showonlyactiveenrol', $instance['showonlyactiveenrol']);
        }
        
        //Raunigr: Pridani tlacitek pro plagiatorstvi a kontrolu ukolu
        //$name = get_string('savechanges', 'assignjava');
        $buttonarray=array();
        $name = 'ohodnotit všechny úkoly';
        //$buttonarray[] = $mform->createElement('submit', 'evaluateall', $name);
        $buttonarray[] = $mform->createElement('submit', 'evaluateall', get_string('evaluate_all', 'assignjava'));
        $mform->addGroup($buttonarray, 'buttonar', '', array(' '), false);
        
        $buttonarray=array();
        $name = 'zkontrolovat všechny úkoly na podobnost';
        //$buttonarray[] = $mform->createElement('submit', 'plagiarismall', $name);
        $buttonarray[] = $mform->createElement('submit', 'plagiarismall', get_string('plagiarism_all', 'assignjava'));
        $mform->addGroup($buttonarray, 'buttonar', '', array(' '), false);
        $mform->addElement('html', $this->get_plagiarism_result());
        // Buttons.
        $this->add_action_buttons(false, get_string('updatetable', 'assignjava'));

        // Hidden params.
        $mform->addElement('hidden', 'contextid', $instance['contextid']);
        $mform->setType('contextid', PARAM_INT);
        $mform->addElement('hidden', 'id', $instance['cm']);
        $mform->setType('id', PARAM_INT);
        $mform->addElement('hidden', 'userid', $instance['userid']);
        $mform->setType('userid', PARAM_INT);
        $mform->addElement('hidden', 'action', 'saveoptions');
        $mform->setType('action', PARAM_ALPHA);   
    }
    
    //Raunigr: Metoda pro vytvoření textu s výsledky z kontroly na podobnost kódu.
    private function get_plagiarism_result()
    {
        global $DB;
        
        list ($course, $cm) = get_course_and_cm_from_cmid(required_param('id', PARAM_INT), 'assignjava');
        $assignment_id = $cm->instance;
        $table = 'assignjava_plagiarism_result';
        
        $result = $DB->get_record($table,array('assignment'=>$assignment_id));
        
        //TODO: předělat na get_string()
        if($result == NULL)
        {
            //return '<b>Úkoly zatím nebyly zkontrolovány na podobnost. </b>';
            return get_string('plagiarism_result_empty', 'assignjava');
        }
        else
        {
            //return '<b>Výsledky: &nbsp</b> <a target="_blank" style="color: blue" href="'.$result->moss.'">odkaz na moss HTML výsledky</a>';
            return get_string('plagiarism_result', 'assignjava', array('date' => date("d.m.y, H:i:s", $result->timestamp), 'ref' => $result->moss));   
        }
    }
}

