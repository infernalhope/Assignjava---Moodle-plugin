<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'assignfeedback_editpdf', language 'cs', branch 'MOODLE_30_STABLE'
 *
 * @package   assignjavafeedback_editpdf
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addtoquicklist'] = 'Přidat do seznamu poznámek';
$string['annotationcolour'] = 'Barva poznámky';
$string['black'] = 'Černá';
$string['blue'] = 'Modrá';
$string['cannotopenpdf'] = 'Nelze otevřít PDF soubor. Může být poškozen nebo v nepodporovaném formátu.';
$string['clear'] = 'Vyčistit';
$string['colourpicker'] = 'Výběr barvy';
$string['command'] = 'Příkaz:';
$string['comment'] = 'Komentáře';
$string['commentcolour'] = 'Barva komentáře';
$string['commentcontextmenu'] = 'Kontextová nabídka komentáře';
$string['couldnotsavepage'] = 'Nelze uložit stránku {$a}';
$string['currentstamp'] = 'Razítko';
$string['deleteannotation'] = 'Odstranit poznámku';
$string['deletecomment'] = 'Odstranit komentář';
$string['deletefeedback'] = 'Odstranit PDF s komentářem';
$string['downloadablefilename'] = 'feedback.pdf';
$string['downloadfeedback'] = 'Stáhnout PDF s komentářem';
$string['drag'] = 'Přetáhnot';
$string['editpdf'] = 'PDF poznámky';
$string['editpdf_help'] = 'Okomenujte práce studentů přímo v prohlížeči a vytvořte PDF, které lze stáhnout';
$string['enabled'] = 'PDF poznámky';
$string['enabled_help'] = 'Je-li povoleno, může učitel při známkování vytvořit okomentovaný soubor PDF. To umožňuje učiteli přidávat komentáře, náčrty a razítka přímo do práce studenta. Poznámky se provádí v prohlížeči a není požadován žádný další software.';
$string['errorgenerateimage'] = 'Chyba generování obrazu v ghostscript, ladící informace: {$a}';
$string['filter'] = 'Filtrovat komentáře...';
$string['generatefeedback'] = 'Vytvořit PDF s komentářem';
$string['generatingpdf'] = 'Vytvářím PDF...';
$string['gotopage'] = 'Přejít na stránku';
$string['green'] = 'Zelená';
$string['gsimage'] = 'Test obrázku Ghostscript';
$string['highlight'] = 'Zvýraznit';
$string['jsrequired'] = 'PDF poznámky vyžadují JavaScript. Prosím, povolte JavaScript ve vašem prohlížeči použít tuto funkci.';
$string['launcheditor'] = 'Spustit PDF editor ...';
$string['line'] = 'Řádek';
$string['loadingeditor'] = 'Nahrávám PDF editor';
$string['navigatenext'] = 'Další stránka';
$string['navigateprevious'] = 'Předchozí stránka';
$string['output'] = 'Výstup:';
$string['oval'] = 'Ovál';
$string['pagenumber'] = 'Stránka {$a}';
$string['pagexofy'] = 'Stránka {$a->page} z {$a->total}';
$string['pathtogspathdesc'] = 'PDF poznámky vyžadují, aby cesta ke ghostscript byla nastavena v {$a}.';
$string['pen'] = 'Pero';
$string['pluginname'] = 'PDF poznámky';
$string['rectangle'] = 'Obdélník';
$string['red'] = 'Červená';
$string['result'] = 'Výsledek:';
$string['searchcomments'] = 'Prohledat komentáře';
$string['select'] = 'Vybrat';
$string['stamp'] = 'Razítko';
$string['stamppicker'] = 'Výběr razítka';
$string['stamps'] = 'Razítka';
$string['stampsdesc'] = 'Razítka musí být soubory obrázků (doporučená velikost: 40x40). Tyto obrázky mohou být použity s razítkem jako nástroj okomentování PDF.';
$string['test_doesnotexist'] = 'Cesta ghostscript neodkazuje na existující soubor';
$string['test_empty'] = 'Cesta ghostscript je prázdná - zadejte správnou cestu, prosím';
$string['testgs'] = 'Otestovat cestu ke ghostscript';
$string['test_isdir'] = 'V ghostscript cesta odkazuje na složku, vložte prosím program ghostscript na určenou cestu';
$string['test_notestfile'] = 'Chybí test PDF';
$string['test_notexecutable'] = 'Ghostscript odkazuje na soubor, který není spustitelný';
$string['test_ok'] = 'Ghostscript cesta se zdá být v pořádku - zkontrolujte si, zda vidíte zprávu na obrázku dole';
$string['tool'] = 'Nástroj';
$string['toolbarbutton'] = '{$a->tool} {$a->shortcut}';
$string['unsavedchanges'] = 'Neuložené změny';
$string['viewfeedbackonline'] = 'Zobrazit okomentované PDF ...';
$string['white'] = 'Bílá';
$string['yellow'] = 'Žlutá';
