<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * This file adds the settings pages to the navigation menu
 *
 * @package   mod_assignjava
 * @copyright 2012 NetSpot {@link http://www.netspot.com.au}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

require_once($CFG->dirroot . '/mod/assignjava/adminlib.php');

$ADMIN->add('modsettings', new admin_category('modassignjavafolder', new lang_string('pluginname', 'mod_assignjava'), $module->is_enabled() === false));

$settings = new admin_settingpage($section, get_string('settings', 'mod_assignjava'), 'moodle/site:config', $module->is_enabled() === false);

if ($ADMIN->fulltree) {
    $menu = array();
    foreach (core_component::get_plugin_list('assignjavafeedback') as $type => $notused) {
        $visible = !get_config('assignjavafeedback_' . $type, 'disabled');
        if ($visible) {
            $menu['assignjavafeedback_' . $type] = new lang_string('pluginname', 'assignjavafeedback_' . $type);
        }
    }

    // The default here is feedback_comments (if it exists).
    $name = new lang_string('feedbackplugin', 'mod_assignjava');
    $description = new lang_string('feedbackpluginforgradebook', 'mod_assignjava');
    $settings->add(new admin_setting_configselect('assignjava/feedback_plugin_for_gradebook',
                                                  $name,
                                                  $description,
                                                  'assignjavafeedback_comments',
                                                  $menu));

    $name = new lang_string('showrecentsubmissions', 'mod_assignjava');
    $description = new lang_string('configshowrecentsubmissions', 'mod_assignjava');
    $settings->add(new admin_setting_configcheckbox('assignjava/showrecentsubmissions',
                                                    $name,
                                                    $description,
                                                    0));

    $name = new lang_string('sendsubmissionreceipts', 'mod_assignjava');
    $description = new lang_string('sendsubmissionreceipts_help', 'mod_assignjava');
    $settings->add(new admin_setting_configcheckbox('assignjava/submissionreceipts',
                                                    $name,
                                                    $description,
                                                    1));

    $name = new lang_string('submissionstatement', 'mod_assignjava');
    $description = new lang_string('submissionstatement_help', 'mod_assignjava');
    $default = get_string('submissionstatementdefault', 'mod_assignjava');
    $settings->add(new admin_setting_configtextarea('assignjava/submissionstatement',
                                                    $name,
                                                    $description,
                                                    $default));

    $name = new lang_string('defaultsettings', 'mod_assignjava');
    $description = new lang_string('defaultsettings_help', 'mod_assignjava');
    $settings->add(new admin_setting_heading('defaultsettings', $name, $description));

    $name = new lang_string('alwaysshowdescription', 'mod_assignjava');
    $description = new lang_string('alwaysshowdescription_help', 'mod_assignjava');
    $setting = new admin_setting_configcheckbox('assignjava/alwaysshowdescription',
                                                    $name,
                                                    $description,
                                                    1);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('allowsubmissionsfromdate', 'mod_assignjava');
    $description = new lang_string('allowsubmissionsfromdate_help', 'mod_assignjava');
    $setting = new admin_setting_configduration('assignjava/allowsubmissionsfromdate',
                                                    $name,
                                                    $description,
                                                    0);
    $setting->set_enabled_flag_options(admin_setting_flag::ENABLED, true);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('duedate', 'mod_assignjava');
    $description = new lang_string('duedate_help', 'mod_assignjava');
    $setting = new admin_setting_configduration('assignjava/duedate',
                                                    $name,
                                                    $description,
                                                    604800);
    $setting->set_enabled_flag_options(admin_setting_flag::ENABLED, true);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('cutoffdate', 'mod_assignjava');
    $description = new lang_string('cutoffdate_help', 'mod_assignjava');
    $setting = new admin_setting_configduration('assignjava/cutoffdate',
                                                    $name,
                                                    $description,
                                                    1209600);
    $setting->set_enabled_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('submissiondrafts', 'mod_assignjava');
    $description = new lang_string('submissiondrafts_help', 'mod_assignjava');
    $setting = new admin_setting_configcheckbox('assignjava/submissiondrafts',
                                                    $name,
                                                    $description,
                                                    0);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('requiresubmissionstatement', 'mod_assignjava');
    $description = new lang_string('requiresubmissionstatement_help', 'mod_assignjava');
    $setting = new admin_setting_configcheckbox('assignjava/requiresubmissionstatement',
                                                    $name,
                                                    $description,
                                                    0);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    // Constants from "locallib.php".
    $options = array(
        'none' => get_string('attemptreopenmethod_none', 'mod_assignjava'),
        'manual' => get_string('attemptreopenmethod_manual', 'mod_assignjava'),
        'untilpass' => get_string('attemptreopenmethod_untilpass', 'mod_assignjava')
    );
    $name = new lang_string('attemptreopenmethod', 'mod_assignjava');
    $description = new lang_string('attemptreopenmethod_help', 'mod_assignjava');
    $setting = new admin_setting_configselect('assignjava/attemptreopenmethod',
                                                    $name,
                                                    $description,
                                                    'none',
                                                    $options);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    // Constants from "locallib.php".
    $options = array(-1 => get_string('unlimitedattempts', 'mod_assignjava'));
    $options += array_combine(range(1, 30), range(1, 30));
    $name = new lang_string('maxattempts', 'mod_assignjava');
    $description = new lang_string('maxattempts_help', 'mod_assignjava');
    $setting = new admin_setting_configselect('assignjava/maxattempts',
                                                    $name,
                                                    $description,
                                                    -1,
                                                    $options);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('teamsubmission', 'mod_assignjava');
    $description = new lang_string('teamsubmission_help', 'mod_assignjava');
    $setting = new admin_setting_configcheckbox('assignjava/teamsubmission',
                                                    $name,
                                                    $description,
                                                    0);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('preventsubmissionnotingroup', 'mod_assignjava');
    $description = new lang_string('preventsubmissionnotingroup_help', 'mod_assignjava');
    $setting = new admin_setting_configcheckbox('assignjava/preventsubmissionnotingroup',
        $name,
        $description,
        0);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('requireallteammemberssubmit', 'mod_assignjava');
    $description = new lang_string('requireallteammemberssubmit_help', 'mod_assignjava');
    $setting = new admin_setting_configcheckbox('assignjava/requireallteammemberssubmit',
                                                    $name,
                                                    $description,
                                                    0);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('teamsubmissiongroupingid', 'mod_assignjava');
    $description = new lang_string('teamsubmissiongroupingid_help', 'mod_assignjava');
    $setting = new admin_setting_configempty('assignjava/teamsubmissiongroupingid',
                                                    $name,
                                                    $description);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('sendnotifications', 'mod_assignjava');
    $description = new lang_string('sendnotifications_help', 'mod_assignjava');
    $setting = new admin_setting_configcheckbox('assignjava/sendnotifications',
                                                    $name,
                                                    $description,
                                                    0);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('sendlatenotifications', 'mod_assignjava');
    $description = new lang_string('sendlatenotifications_help', 'mod_assignjava');
    $setting = new admin_setting_configcheckbox('assignjava/sendlatenotifications',
                                                    $name,
                                                    $description,
                                                    0);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('sendstudentnotificationsdefault', 'mod_assignjava');
    $description = new lang_string('sendstudentnotificationsdefault_help', 'mod_assignjava');
    $setting = new admin_setting_configcheckbox('assignjava/sendstudentnotifications',
                                                    $name,
                                                    $description,
                                                    1);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('blindmarking', 'mod_assignjava');
    $description = new lang_string('blindmarking_help', 'mod_assignjava');
    $setting = new admin_setting_configcheckbox('assignjava/blindmarking',
                                                    $name,
                                                    $description,
                                                    0);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('markingworkflow', 'mod_assignjava');
    $description = new lang_string('markingworkflow_help', 'mod_assignjava');
    $setting = new admin_setting_configcheckbox('assignjava/markingworkflow',
                                                    $name,
                                                    $description,
                                                    0);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);

    $name = new lang_string('markingallocation', 'mod_assignjava');
    $description = new lang_string('markingallocation_help', 'mod_assignjava');
    $setting = new admin_setting_configcheckbox('assignjava/markingallocation',
                                                    $name,
                                                    $description,
                                                    0);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
    $settings->add($setting);
}

$ADMIN->add('modassignjavafolder', $settings);
// Tell core we already added the settings structure.
$settings = null;

$ADMIN->add('modassignjavafolder', new admin_category('assignjavasubmissionplugins',
    new lang_string('submissionplugins', 'assignjava'), !$module->is_enabled()));
$ADMIN->add('assignjavasubmissionplugins', new assignjava_admin_page_manage_assignjava_plugins('assignjavasubmission'));
$ADMIN->add('modassignjavafolder', new admin_category('assignjavafeedbackplugins',
    new lang_string('feedbackplugins', 'assignjava'), !$module->is_enabled()));
$ADMIN->add('assignjavafeedbackplugins', new assignjava_admin_page_manage_assignjava_plugins('assignjavafeedback'));

foreach (core_plugin_manager::instance()->get_plugins_of_type('assignjavasubmission') as $plugin) {
    /** @var \mod_assignjava\plugininfo\assignjavasubmission $plugin */
    $plugin->load_settings($ADMIN, 'assignjavasubmissionplugins', $hassiteconfig);
}

foreach (core_plugin_manager::instance()->get_plugins_of_type('assignjavafeedback') as $plugin) {
    /** @var \mod_assignjava\plugininfo\assignjavafeedback $plugin */
    $plugin->load_settings($ADMIN, 'assignjavafeedbackplugins', $hassiteconfig);
}
