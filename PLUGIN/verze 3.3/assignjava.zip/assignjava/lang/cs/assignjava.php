<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'assign', language 'cs', branch 'MOODLE_33_STABLE'
 *
 * @package   assign
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['activityoverview'] = 'Máte jeden či více nových JAVA úkolů (klikněte zde pro zobrazení).';
$string['addattempt'] = 'Povolit další pokus';
$string['addnewattempt'] = 'Přidat nový pokus';
$string['addnewattemptfromprevious'] = 'Přidat nový pokus na základě posledního odevzdání';
$string['addnewattemptfromprevious_help'] = 'Tímto se vytvoří kopie předchozího odevzdání, na které budete moci dále pracovat.';
$string['addnewattempt_help'] = 'Tímto se vytvoří nový čistý formulář, na kterém můžete začít pracovat od začátku.';
$string['addnewgroupoverride'] = 'Přidat skupinové přenastavení';
$string['addnewuseroverride'] = 'Přidat přenastavení uživatele';
$string['addsubmission'] = 'Přidat řešení úkolu';
$string['allocatedmarker'] = 'Přidělení hodnotitelé';
$string['allocatedmarker_help'] = 'Hodnotitelé přidělené tomuto řešení úkolu';
$string['allowsubmissions'] = 'Povolit uživateli pokračování v hodnocení odevzdaného úkolu.';
$string['allowsubmissionsanddescriptionfromdatesummary'] = 'Detaily úkolu a formulář pro odevzdání bude dostupný od <strong>{$a}</strong>';
$string['allowsubmissionsfromdate'] = 'Povolit odevzdání úkolů od';
$string['allowsubmissionsfromdate_help'] = 'Je-li povoleno, studenti nebudou moci odevzdat svá řešení před nastaveným okamžikem. Není-li povoleno, studenti mohou odevzdávat okamžitě.';
$string['allowsubmissionsfromdatesummary'] = 'Odevzdat úkol bude možné od <strong>{$a}</strong>';
$string['allowsubmissionsshort'] = 'Povolit změny odevzdaného úkolu';
$string['alwaysshowdescription'] = 'Povolit zobrazení popisu';
$string['alwaysshowdescription_help'] = 'Je-li zakázáno, bude se popis úkolu studentům zobrazovat až poté, co bude možné odevzdávat úkol.';
$string['applytoteam'] = 'Použít hodnocení pro celou skupinu';
$string['assign:addinstance'] = 'Přidat nový úkol';
$string['assign:editothersubmission'] = 'Upravit další řešení studentů';
$string['assign:exportownsubmission'] = 'Exportovat vlastní řešení do portfolia';
$string['assignfeedback'] = 'Modul hodnocení';
$string['assignfeedbackpluginname'] = 'Modul hodnocení';
$string['assign:grade'] = 'Známkovat úkoly';
$string['assign:grantextension'] = 'Poskytnout prodloužení';
$string['assign:manageallocations'] = 'Správa přidělení hodnotitelů k odevzdaným úkolům';
$string['assign:managegrades'] = 'Revize a zveřejnění známek';
$string['assign:manageoverrides'] = 'Správa  přenastavení úkolu';
$string['assignmentisdue'] = 'Úkol je zpožděn';
$string['assignmentmail'] = '{$a->grader} ohodnotil  vaše řešení úkolu  "{$a->assignment}".

Hodnocení naleznete u svého úkolu na adrese:
{$a->url}.';
$string['assignmentmailhtml'] = '<p>{$a->grader} ohodnotil  vaše řešení úkolu  <i>"{$a->assignment}"</i>. </p>
<p>Hodnocení naleznete u <a href="{$a->url}">svého úkolu</p>.';
$string['assignmentmailsmall'] = '{$a->grader} ohodnotil vaše řešení úkolu "{$a->assignment}". Více informací najdete na stránce s vaším řešením.';
$string['assignmentname'] = 'Název úkolu';
$string['assignmentplugins'] = 'Rozšíření typu úkol';
$string['assignmentsperpage'] = 'Úkolů na stránku';
$string['assign:receivegradernotifications'] = 'Zasílat oznámení o řešení úkolu hodnotiteli';
$string['assign:releasegrades'] = 'Zveřejnění známek';
$string['assign:revealidentities'] = 'Ukázat identitu studentů';
$string['assign:reviewgrades'] = 'Přezkoumání známek';
$string['assignsubmission'] = 'Rozšíření typu odevzdaný úkol';
$string['assignsubmissionpluginname'] = 'Rozšíření typu odevzdaný úkol';
$string['assign:submit'] = 'Odevzdávat úkoly';
$string['assign:view'] = 'Prohlížet úkoly';
$string['assign:viewblinddetails'] = 'Zobrazit identitu studentů v případě známkování naslepo';
$string['assign:viewgrades'] = 'Zobrazit známky';
$string['attemptheading'] = 'Pokus č. {$a->attemptnumber}: {$a->submissionsummary}';
$string['attempthistory'] = 'Předchozí pokusy';
$string['attemptnumber'] = 'Číslo pokusu';
$string['attemptreopenmethod'] = 'Opětovné otevření pokusů';
$string['attemptreopenmethod_help'] = 'Určuje, zda a za jakých podmínek dojde k opětovnému otevření pokusů.

K dispozici jsou možnosti:
<ul>
<li>Nikdy - Jednou odevzdané řešení nelze znovu otevřít pro úpravy.</li>
<li>Ručně - Vyučující může odevzdaná řešení znovu otevřít pro úpravy.</li>
<li>Automaticky dokud neuspěje - Odevzdané řešení je automaticky otevřeno pro další úpravy, dokud za něj není udělena známka potřebná pro splnění úkolu (hodnotu této potřebné známky lze nastavit v Klasifikaci).</li>
</ul>';
$string['attemptreopenmethod_manual'] = 'Ručně';
$string['attemptreopenmethod_none'] = 'Nikdy';
$string['attemptreopenmethod_untilpass'] = 'Automaticky dokud neuspěje';
$string['attemptsettings'] = 'Nastavení pokusů';
$string['availability'] = 'Dostupnost';
$string['backtoassignment'] = 'Zpět k úkolu';
$string['batchoperationconfirmaddattempt'] = 'Povolit další pokus pro označená odevzdaná řešení?';
$string['batchoperationconfirmdownloadselected'] = 'Uložit  označená odevzdaná řešení?';
$string['batchoperationconfirmgrantextension'] = 'Poskytnout prodloužení pro všechny vybrané odevzdané úkoly?';
$string['batchoperationconfirmlock'] = 'Zamknout všechny vybrané odevzdané úkoly?';
$string['batchoperationconfirmreverttodraft'] = 'Vrátit vybrané odevzdané úkoly do stavu návrh?';
$string['batchoperationconfirmsetmarkingallocation'] = 'Nastavit přidělení známek všech vybraných odevzdaných úkolech?';
$string['batchoperationconfirmsetmarkingworkflowstate'] = 'Nastavit zpracování známek všech vybraných odevzdaných úkolech?';
$string['batchoperationconfirmunlock'] = 'Odemknout všechny vybrané odevzdané úkoly?';
$string['batchoperationlock'] = 'zamknout odevzdané úkoly';
$string['batchoperationreverttodraft'] = 'vrátit odevzdaný úkol do stavu návrh';
$string['batchoperationsdescription'] = 'S označenými:';
$string['batchoperationunlock'] = 'odemknout odevzdané úkoly';
$string['batchsetallocatedmarker'] = 'Nastavit přidělení hodnotitele pro {$a} vybrané uživatele.';
$string['batchsetmarkingworkflowstateforusers'] = 'Nastavit zpracování známky pro {$a} vybrané uživatele.';
$string['blindmarking'] = 'Známkování naslepo';
$string['blindmarkingenabledwarning'] = 'Pro tuto činnost je povoleno známkování naslepo.';
$string['blindmarking_help'] = 'Známkování naslepo skryje pro hodnotitele identitu studentů. Nastavení anonymního známkování bude zamčeno po odevzdání úkolu nebo hodnocení úkolu.';
$string['changefilters'] = 'Změnit filtry';
$string['changegradewarning'] = 'Tento úkol již obsahuje oznámkovaná řešení. Změna známky neovlivní tato již oznámkovaná řešení. Bude potřeba znovu ohodnotit všechna odevzdaná řešení, chcete-li změnit i stávající známky.';
$string['changeuser'] = 'Změnit uživatele';
$string['choosegradingaction'] = 'Akce oznámkování';
$string['choosemarker'] = 'Výběr ...';
$string['chooseoperation'] = 'Vyberte operaci';
$string['clickexpandreviewpanel'] = 'Kliknutím rozbalíte panel revize známek';
$string['collapsegradepanel'] = 'Sbalit panel známek';
$string['collapsereviewpanel'] = 'Sbalit panel revize známek';
$string['comment'] = 'Komentář';
$string['completionsubmit'] = 'Pro splnění této činnosti musí student odevzdat úkol';
$string['configshowrecentsubmissions'] = 'Všem zobrazovat upozornění o odevzdaných úkolech v přehledu nedávné činnosti.';
$string['confirmbatchgradingoperation'] = 'Jste si jist, že chcete {$a->operation} pro {$a->count} studenty?';
$string['confirmsubmission'] = 'Jste si jisti, že chcete odeslat svou práci k hodnocení? Nebudete moci provádět žádné další změny.';
$string['conversionexception'] = 'Nelze konvertovat úkol. Výjimka je: {$a}.';
$string['couldnotconvertgrade'] = 'Nelze konvertovat hodnocení úkolu uživatele {$a}.';
$string['couldnotconvertsubmission'] = 'Nelze konvertovat odevzdaný úkol uživatele {$a}.';
$string['couldnotcreatecoursemodule'] = 'Nelze vytvořit modul kurzu.';
$string['couldnotcreatenewassignmentinstance'] = 'Nelze vytvořit novou instanci úkolu.';
$string['couldnotfindassignmenttoupgrade'] = 'Nelze nalézt staré instance úkolů k aktualizaci.';
$string['currentattempt'] = 'Toto je pokus č. {$a}.';
$string['currentattemptof'] = 'Toto je pokus č. {$a->attemptnumber} (celkem je povoleno {$a->maxattempts} pokusů).';
$string['currentgrade'] = 'Momentální známka v klasifikaci kurzu';
$string['cutoffdate'] = 'Datum ukončení';
$string['cutoffdatecolon'] = 'Datum ukončení: {$a}';
$string['cutoffdatefromdatevalidation'] = 'Datum ukončení musí být po datu, kterým bylo umožněno odevzdávat úkoly';
$string['cutoffdate_help'] = 'Je-li nastaveno, nebude povoleno odevzdání úkolu po tomto datu, bez prodloužení termínu';
$string['cutoffdatevalidation'] = 'Datum ukončení nesmí předcházet termínu odevzdání.';
$string['defaultlayout'] = 'Obnovit původní vzhled';
$string['defaultsettings'] = 'Výchozí nastavení úkolu';
$string['defaultsettings_help'] = 'Tato nastavení definují výchozí hodnoty pro nové úkoly.';
$string['defaultteam'] = 'Výchozí skupina';
$string['deleteallsubmissions'] = 'Odstranit všechna řešení úkolu';
$string['description'] = 'Popis';
$string['disabled'] = 'Zakázáno';
$string['downloadall'] = 'Uložit odevzdané úkoly';
$string['downloadasfolders'] = 'Stáhnout příspěvky do složek';
$string['downloadasfolders_help'] = 'V případě, že odevzdaný úkol obsahuje více než jeden soubor, pak mohou být úkoly staženy do složek. Každý úkol bude umístěn do samostatné složky, se strukturou složek zachované pro všechny podsložky  a soubory nebudou přejmenovány.';
$string['downloadselectedsubmissions'] = 'Uložit vybrané odevzdané úkoly';
$string['duedate'] = 'Termín odevzdání';
$string['duedatecolon'] = 'Termín odevzdání: {$a}';
$string['duedate_help'] = 'Určuje, do jakého termínu musí studenti odevzdat svoji práci. Řešení je možno odevzdat i po tomto termínu, ale budou v tom případě označena jako pozdní odevzdání. Pro úplné zabránění odevzdávání po určitém termínu nastavte datum ukončení.';
$string['duedateno'] = 'Bez termínu odevzdání';
$string['duedatereached'] = 'Termín pro odevzdání tohoto úkolu vypršel';
$string['duedatevalidation'] = 'Datum ukončení musí být po datu povolující odevzdání úkolu';
$string['duplicateoverride'] = 'Duplikovat přenastavení';
$string['editaction'] = 'Akce ...';
$string['editattemptfeedback'] = 'Úprava hodnocení pro pokus č. {$a}.';
$string['editingpreviousfeedbackwarning'] = 'Upravujete hodnocení k odevzdanému řešení, které není nejnovější. Toto je pokus č. {$a->attemptnumber} z celkového počtu {$a->totalattempts}.';
$string['editingstatus'] = 'Stav úprav';
$string['editonline'] = 'Upravit online';
$string['editoverride'] = 'Upravit přenastavení';
$string['editsubmission'] = 'Upravit řešení úkolu';
$string['editsubmission_help'] = 'Zde můžete provést změny ve vašem odevzdaném řešení úkolu.';
$string['editsubmissionother'] = 'Upravit řešení úkolu {$a}';
$string['enabled'] = 'Povoleno';
$string['errornosubmissions'] = 'Žádná odevzdaná řešení ke stažení.';
$string['errorquickgradingvsadvancedgrading'] = 'Hodnocení nebylo uloženo, neboť tento úkol v současné době využívá pokročilé hodnocení';
$string['errorrecordmodified'] = 'Hodnocení nebylo uloženo, protože někdo změnil jeden nebo více záznamů poté, co jste načetli tuto stránku.';
$string['eventallsubmissionsdownloaded'] = 'Všechny odevzdané úkoly se stahují';
$string['eventassessablesubmitted'] = 'Úkol byl odeslán.';
$string['eventbatchsetmarkerallocationviewed'] = 'Zobrazeno přidělení hodnotitelů';
$string['eventbatchsetworkflowstateviewed'] = 'Zobrazení nastavení zpracování známek';
$string['eventextensiongranted'] = 'Bylo poskytnuto prodloužení termínu.';
$string['eventfeedbackupdated'] = 'Komentář aktualizován';
$string['eventfeedbackviewed'] = 'Komentář zobrazen';
$string['eventgradingformviewed'] = 'Hodnotící formulář zobrazen';
$string['eventgradingtableviewed'] = 'Zobrazena tabulka známek';
$string['eventidentitiesrevealed'] = 'Identita studentů byla odhalena.';
$string['eventmarkerupdated'] = 'Přidělený hodnotitel byl aktualizován.';
$string['eventoverridecreated'] = 'Vytvořeno  přenastavení úkolu';
$string['eventoverridedeleted'] = 'Odstraněno přenastavení úkolu';
$string['eventoverrideupdated'] = 'Aktualizováno přenastavení úkolu';
$string['eventrevealidentitiesconfirmationpageviewed'] = 'Zobrazena stránka s potvrzením odhalením identity.';
$string['eventstatementaccepted'] = 'Uživatel přijal prohlášení o odevzdaném úkolu.';
$string['eventsubmissionconfirmationformviewed'] = 'Zobrazen formulář potvrzení řešení úkolu.';
$string['eventsubmissioncreated'] = 'Vytvořeno řešení úkolu.';
$string['eventsubmissionduplicated'] = 'Uživatel zopakoval své řešení úkolu.';
$string['eventsubmissionformviewed'] = 'Zobrazen formulář pro řešení úkolu.';
$string['eventsubmissiongraded'] = 'Odevzdaný úkol byl známkován.';
$string['eventsubmissionlocked'] = 'Odevzdaný úkol byl pro uživatele zamčen.';
$string['eventsubmissionstatusupdated'] = 'Stav odevzdaného úkolu byl aktualizován.';
$string['eventsubmissionstatusviewed'] = 'Byl zobrazen stav odevzdaného úkolu.';
$string['eventsubmissionunlocked'] = 'Odevzdaný úkol byl uživateli odemčen.';
$string['eventsubmissionupdated'] = 'Uživatel uložit svůj úkol.';
$string['eventsubmissionviewed'] = 'Zobrazeno řešení úkolu.';
$string['eventworkflowstateupdated'] = 'Stav zpracování byl aktualizován.';
$string['expandreviewpanel'] = 'Rozbalit panel revize známek';
$string['extensionduedate'] = 'Prodloužený termín odevzdání';
$string['extensionnotafterduedate'] = 'Prodloužený termín odevzdání musí být po termínu odevzdání';
$string['extensionnotafterfromdate'] = 'Prodloužený termín odevzdání musí být po datu umožňující odevzdání úkolu';
$string['feedback'] = 'Hodnocení';
$string['feedbackavailablehtml'] = '{$a->username} ohodnotil váš odevzdaný úkol "<i>{$a->assignment}</i>".<br /><br />
Hodnocení si můžete zobrazit u svého <a href="{$a->url}">odevzdaného úkolu</a>.';
$string['feedbackavailablesmall'] = '{$a->username} ohodnotil úkol {$a->assignment}';
$string['feedbackavailabletext'] = '{$a->username} ohodnotil váš odevzdaný úkol "{$a->assignment}".

Hodnocení si můžete zobrazit u svého odevzdaného úkolu:

    {$a->url}';
$string['feedbackplugin'] = 'Modul hodnocení';
$string['feedbackpluginforgradebook'] = 'Modul, který vkládá hodnocení do klasifikace';
$string['feedbackpluginforgradebook_help'] = 'Pouze jeden z modulů hodnocení může vkládat údaje do klasifikace kurzu.';
$string['feedbackplugins'] = 'Moduly hodnocení';
$string['feedbacksettings'] = 'Nastavení hodnocení';
$string['feedbacktypes'] = 'Typy hodnocení';
$string['filesubmissions'] = 'Odevzdat soubor(y)';
$string['filter'] = 'Filtr';
$string['filtergrantedextension'] = 'Prodloužení povoleno';
$string['filternone'] = 'Bez filtru';
$string['filternotsubmitted'] = 'Neodevzdáno';
$string['filterrequiregrading'] = 'Požadováno hodnocení';
$string['filtersubmitted'] = 'Odevzdáno';
$string['gradeabovemaximum'] = 'Hodnocení musí být menší nebo rovno {$a}.';
$string['gradebelowzero'] = 'Hodnocení musí být větší nebo rovno nule.';
$string['gradecanbechanged'] = 'Známka může být změněna';
$string['gradechangessaveddetail'] = 'Změny známky a zpětná vazba byly uloženy';
$string['graded'] = 'Udělena známka';
$string['gradedby'] = 'Hodnoceno';
$string['gradedon'] = 'Hodnoceno na';
$string['gradelocked'] = 'Známka je v klasifikaci zamčena nebo přepsána.';
$string['gradeoutof'] = 'Hodnoceno z {$a}';
$string['gradeoutofhelp'] = 'Hodnocení';
$string['gradeoutofhelp_help'] = 'Zde zadejte známku za úkol studenta. Může obsahovat desetetinná místa.';
$string['gradersubmissionupdatedhtml'] = '{$a->username} upravil(a) své vypracování úkolu <em>"{$a->assignment}"</em> (upraveno {$a->timeupdated}).<br /><br />Aktualizované řešení je <a href="{$a->url}">dostupné zde</a>.';
$string['gradersubmissionupdatedsmall'] = '{$a->username} aktualizoval svůj odevzdaný úkol {$a->assignment}.';
$string['gradersubmissionupdatedtext'] = '{$a->username} upravil(a) své vypracování úkolu "{$a->assignment}" (upraveno {$a->timeupdated}).

Aktualizované řešení je dostupné na:

{$a->url}.';
$string['gradestudent'] = 'Hodnocení studenta: (id={$a->id}, fullname={$a->fullname}).';
$string['gradeuser'] = 'Hodnocení {$a}';
$string['grading'] = 'Hodnocení';
$string['gradingchangessaved'] = 'Změny známek byly uloženy';
$string['gradingduedate'] = 'Připomenout mi termín známkování';
$string['gradingduedate_help'] = 'Předpokládaný termín, do kterého by mělo být dokončeno známkování odevzdaných úkolů. Toto datum se používá pro stanovení priorit oznámení Nástěnky učitelům.';
$string['gradingmethodpreview'] = 'Kriteria hodnocení';
$string['gradingoptions'] = 'Možnosti';
$string['gradingstatus'] = 'Stav hodnocení';
$string['gradingstudent'] = 'Hodnocený student';
$string['gradingsummary'] = 'Souhrn hodnocení';
$string['grantextension'] = 'Poskytnout prodloužení';
$string['grantextensionforusers'] = 'Poskytnout prodloužení pro {$a} studentů';
$string['groupoverrides'] = 'Přenastavení skupiny';
$string['groupoverridesdeleted'] = 'Přenastavení skupiny odstraněno';
$string['groupsnone'] = 'V tomto kurzu neexistují žádné skupiny';
$string['groupsubmissionsettings'] = 'Nastavení skupinového řešení';
$string['hiddenuser'] = 'Účastník';
$string['hideshow'] = 'Skrýt/zobrazit';
$string['inactiveoverridehelp'] = '* Při pokusu o úkol nemá student správnou skupinu nebo roli';
$string['instructionfiles'] = 'Soubory s návody';
$string['introattachments'] = 'Další soubory';
$string['introattachments_help'] = 'V zadání úkolu mohou být zadány další soubory, jako například šablony pro řešení úkolu. Odkazy na stažení souboru pak budou zobrazeny pod popisem úkolu .';
$string['invalidfloatforgrade'] = 'Neplatné hodnocení: {$a}';
$string['invalidgradeforscale'] = 'Pro aktuální škálu není poskytnuté hodnocení správné.';
$string['invalidoverrideid'] = 'Neplatné id přenastavení';
$string['lastmodifiedgrade'] = 'Poslední změna (hodnocení)';
$string['lastmodifiedsubmission'] = 'Poslední změna (odevzdaný úkol)';
$string['latesubmissions'] = 'Zpožděné odevzdané úkoly';
$string['latesubmissionsaccepted'] = 'Povoleno do  {$a}';
$string['loading'] = 'Nahrávám ...';
$string['locksubmissionforstudent'] = 'Zamezit odevzdání úkolu studenta: (id={$a->id}, celé jméno={$a->fullname}).';
$string['locksubmissions'] = 'Zamknout odevzdání úkolů';
$string['manageassignfeedbackplugins'] = 'Správa modulů pro hodnocení úkolů';
$string['manageassignsubmissionplugins'] = 'Správa modulů pro odevzdání úkolů';
$string['marker'] = 'Hodnotitel';
$string['markerfilter'] = 'Filtr hodnotitele';
$string['markerfilternomarker'] = 'Žádný hodnotitel';
$string['markingallocation'] = 'Použijte přidělení známek';
$string['markingallocation_help'] = 'Je-li povoleno spolu s postupem známkování, mohou být hodnotitelé přiděleni studentům.';
$string['markingworkflow'] = 'Použít postup známkování';
$string['markingworkflow_help'] = 'Je-li povoleno, musí známky, než jsou studentům zveřejněny, projít řadou stavů postupu. To dovoluje více kol známkováni a umožňuje, aby všechny známky byly studentům zveřejněny najednou.';
$string['markingworkflowstate'] = 'Stav postupu známkování';
$string['markingworkflowstate_help'] = 'Možné stavy workflow  (v závislosti na nastavení):

* Neznámkováno - hodnotitel dosud nezačat
* Známkováno - hodnotitel zahájil známkování, ale dosud neskončil
* Známkování ukončeno - hodnotitel dokončil známkování, ale může se vrátit ke kontrole a opravě
* Recenzováno - recenzent odpovědný za kontrolu kvality provádí recenzi hodnocení
* Připraveno ke zveřejnění - proběhle recenze, ale čeká se na zveřejnění
* Zveřejněno - studenti mají přístup ke známkám a komentářům';
$string['markingworkflowstateinmarking'] = 'Známkováno';
$string['markingworkflowstateinreview'] = 'Revidováno';
$string['markingworkflowstatenotmarked'] = 'Bez známky';
$string['markingworkflowstatereadyforrelease'] = 'Připraveno ke zveřejnění';
$string['markingworkflowstatereadyforreview'] = 'Známkování dokončeno';
$string['markingworkflowstatereleased'] = 'Zveřejněno';
$string['maxattempts'] = 'Nejvyšší počet pokusů';
$string['maxattempts_help'] = 'Nejvyšší možný počet pokusů na řešení úkolu pro každého studenta. Po dosažení tohoto počtu již nebude možno opětovně otevřít odevzdané řešení pro další úpravy.';
$string['maxgrade'] = 'Maximální známka';
$string['maxperpage'] = 'Maximum úkolů na stránku';
$string['maxperpage_help'] = 'Maximální počet úkolů zobrazených hodnotiteli na stránce pro známkování. Užitečné, aby se zabránilo překročení časových limitů na kurzech s velmi velkými počty studentů.';
$string['messageprovider:assign_notification'] = 'Oznámení úkolu';
$string['modulename'] = 'JAVA úkol';
$string['modulename_help'] = 'Java úkol (assignjava) je postaven na klasickém pluginu "úkol" (assign) poskytovaného Moodlem, proto je práce s Java úkoly téměř stejná.

Studenti vždy musí odevzdat JAR soubor, který je použit při automatizovaném ohodnocení domácího úkolu a JAVA soubory, které se budou kontrolovat na podobnost zdrojových kódů (zpravidla určí učitel). Je povoleno, aby byl JAR soubor + JAVA soubory, popřípadě celý projekt obsahující JAR soubor + JAVA soubory, zabalen do ZIP souboru.

Učitel v nastavení Java úkolu má k dispozici drag&drop element, do kterého musí vložit testy ve formě, pro kterou platí stejné podmínky, jako pro studentův domácí úkol.

Po odevzdání domácího úkolu studenti ihned uvidí výsledky z automatizovaného ohodnocení jejich domácích úkolů, které jsou v komentáři k úkolu. Učitel může v sekci "Zobrazit/hodnotit všechny odevzdané úkoly" spustit automatizované testování pro všechny studenty, kteří již odevzdali svůj domácí úkol. V sekci se také nachází tlačítko na spuštění kontroly na podobnost kódu, kde výsledek (URL adresa) se zobrazí pod tlačítkem. Některé motivy systému Moodle způsobují, že se tyto tlačítka nezobrazují (vhodné motiy jsou Clean, More, Aardvark).

<b>Nepoužívat nastavení "Požadovat, aby studenti klikli na tlačítko Odeslat!"</b> Plugin v takovém případě nebude fungovat korektně.

DEMO ukázky lze nalézt v  <a href="https://github.com/infernalhope/Assignjava---Moodle-plugin">manuálu</a>.
Bližší informace o pluginu lze nalézt v diplomové práci:
RAUNIGR, Petr. Moodle addon jako nástroj pro automatizovanou kontrolu domácích úkolů z programování (Java). Ostrava, 2017. Diplomová práce. Ostravská univerzita v Ostravě. Vedoucí práce RNDr. Marek Vajgl, Ph. D..';
$string['modulenameplural'] = 'JAVA úkoly';
$string['moreusers'] = '{$a} více ...';
$string['multipleteams'] = 'Člen více než jedné skupiny';
$string['multipleteams_desc'] = 'Tento úkol vyžaduje řešení úkolu ve skupinách. Jste členem více než jedné skupiny. Aby bylo možné  odeslat řešení úkolu, musíte být členem pouze jedné skupiny. Obraťte se na svého učitele, aby aktualizoval vaše členství ve skupině.';
$string['multipleteamsgrader'] = 'Člen více než jedné skupiny, nemůže odevzdat řešení úkolu.';
$string['mysubmission'] = 'Můj odevzdaný úkol:';
$string['newsubmissions'] = 'Odevzdané úkoly';
$string['noattempt'] = 'Neodevzdáno';
$string['noclose'] = 'Není datum ukončení';
$string['nofiles'] = 'Žádný soubor.';
$string['nofilters'] = 'Bez filtru';
$string['nograde'] = 'Žádné hodnocení.';
$string['nolatesubmissions'] = 'Nelze odevzdat zpožděné úkoly';
$string['nomoresubmissionsaccepted'] = 'Povoleny pouze pro účastníky, kterým byl prodloužen termín';
$string['none'] = 'Nic';
$string['noonlinesubmissions'] = 'Tento úkol nevyžaduje odpověď online';
$string['noopen'] = 'Není datum zahájení';
$string['nooverridedata'] = 'Je nutné přenastavit alespoň jedno nastavení úkolu.';
$string['nosavebutnext'] = 'Další';
$string['nosubmission'] = 'K tomuto úkolu nebylo nic odevzdáno';
$string['nosubmissionsacceptedafter'] = 'Ukončení odevzdávání';
$string['noteam'] = 'Není členem žádné skupiny';
$string['noteam_desc'] = 'Tento úkol vyžaduje řešení úkolu ve skupinách. Nejste členem žádné skupiny, takže nelze vytvořit řešení úkolu. Obraťte se na učitele, kteří vás přidají do skupiny.';
$string['noteamgrader'] = 'Není členem žádné skupiny, nemůže odevzdat řešení úkolu.';
$string['notgraded'] = 'Nehodnoceno';
$string['notgradedyet'] = 'Zatím neudělena známka';
$string['notifications'] = 'Oznámení';
$string['notsubmittedyet'] = 'Zatím neodevzdáno';
$string['nousers'] = 'Žádní uživatelé';
$string['nousersselected'] = 'Nevybrán uživatel';
$string['numberofdraftsubmissions'] = 'Návrhy';
$string['numberofparticipants'] = 'Účastníci';
$string['numberofsubmissionsneedgrading'] = 'Nutno ohodnotit';
$string['numberofsubmittedassignments'] = 'Odevzdáno';
$string['numberofteams'] = 'Skupiny';
$string['offline'] = 'Nejsou požadovány odpovědi online';
$string['open'] = 'Otevřeno';
$string['outlinegrade'] = 'Hodnocení: {$a}';
$string['outof'] = '{$a->current} ze {$a->total}';
$string['overdue'] = '<font color="red">Úkol má zpoždění: {$a}</font>';
$string['override'] = 'Přenastavení';
$string['overridedeletegroupsure'] = 'Jste si jisti, že chcete smazat přenastavení pro skupinu {$a}?';
$string['overridedeleteusersure'] = 'Jste si jisti, že chcete smazat přenastavení pro uživatele {$a}?';
$string['overridegroup'] = 'Přenastavit skupinu';
$string['overridegroupeventname'] = '{$a->assign} - {$a->group}';
$string['overrides'] = 'Přenastavit';
$string['overrideuser'] = 'Přenastavit uživatele';
$string['overrideusereventname'] = '{$a->assign} -  Přenastavit';
$string['page-mod-assign-view'] = 'Hlavní stránka úkolu';
$string['page-mod-assign-x'] = 'Jakákoliv stránka úkolu';
$string['paramtimeremaining'] = '{$a} zůstává';
$string['participant'] = 'Účastník';
$string['pluginadministration'] = 'Správa Java úkolu';
$string['pluginname'] = 'JAVA úkol';
$string['preventsubmissionnotingroup'] = 'Pro odevzdání úkolu vyžadovat zařazení do týmu';
$string['preventsubmissionnotingroup_help'] = 'Pokud je povoleno, nebudou uživatelé, kteří nejsou členy skupiny/týmu, schopni odevzdat úkol.';
$string['preventsubmissions'] = 'Zabránit uživateli provést další odevzdání k tomuto úkolu.';
$string['preventsubmissionsshort'] = 'Zabránit změnám v odevzdaných úkolech';
$string['previous'] = 'Předchozí';
$string['quickgrading'] = 'Rychlé hodnocení';
$string['quickgradingchangessaved'] = 'Změny hodnocení uloženy';
$string['quickgrading_help'] = 'Rychlé hodnocení umožňuje známkovat úkoly (a očekávané výstupy) v tabulce hodnocení odevzdaných úkolů. Není kompatibilní s pokročilým známkováním a není doporučeno hodnocení více hodnotiteli.';
$string['quickgradingresult'] = 'Rychlé hodnocení';
$string['recordid'] = 'Identifikátor';
$string['removeallgroupoverrides'] = 'Smazat všechny přenastavení skupin';
$string['removealluseroverrides'] = 'Smazat všechny přenastavení uživatele';
$string['reopenuntilpassincompatiblewithblindmarking'] = 'Znovuotevření před dokončením není kompatibilní s hodnocením naslepo, protože do odhalení identity studentů nejsou známky uvolněny.';
$string['requireallteammemberssubmit'] = 'Požadováno potvrzení všech členů skupiny';
$string['requireallteammemberssubmit_help'] = 'Je-li povoleno, musí všichni členové skupiny nejprve kliknout na tlačítko Odeslat a teprve poté bude skupinová práce považována za odevzdanou. Pokud je možnost nastavena na „Ne“, bude práce považována za odevzdanou, jakmile kterýkoli člen skupiny klikne na tlačítko Odeslat. (Podmíněno volbou "Ano" u Požadovat, aby studenti klikli na tlačítko Odeslat)';
$string['requiresubmissionstatement'] = 'Požadovat, aby studenti souhlasili s předloženým prohlášením, které se týká všech odevzdaných prací v tomto Úkolu.';
$string['requiresubmissionstatement_help'] = 'Požadovat, aby studenti pro řešení tohoto úkolu přijali předložené prohlášení';
$string['revealidentities'] = 'Odhalit identitu studentů';
$string['revealidentitiesconfirm'] = 'Jste si jisti, že chcete v úkolu zobrazit identitu studentů? Tuto operaci nelze vrátit zpět. Poté, co bude zobrazena identita studentů, budou známky uvolněny do přehledu známek.';
$string['reverttodefaults'] = 'Vrátit úkol na výchozí hodnoty';
$string['reverttodraft'] = 'Vrátit úkol do stavu návrh.';
$string['reverttodraftforstudent'] = 'Vrátit úkol do stavu návrh pro studenta: (id={$a->id}, fullname={$a->fullname}).';
$string['reverttodraftshort'] = 'Vrátit úkol do stavu návrh';
$string['reviewed'] = 'Revidováno';
$string['save'] = 'Uložit';
$string['saveallquickgradingchanges'] = 'Uložit všechny změny hodnocení';
$string['saveandcontinue'] = 'Uložit a pokračovat';
$string['savechanges'] = 'Uložit změny';
$string['savegradingresult'] = 'Známka';
$string['savenext'] = 'Uložit a zobrazit další';
$string['saveoverrideandstay'] = 'Uložit a vložit další přenastavení';
$string['savingchanges'] = 'Uložit změny...';
$string['scale'] = 'Měřítko';
$string['search:activity'] = 'Úkoly - informace';
$string['selectedusers'] = 'Vybraní uživatelé';
$string['selectlink'] = 'Vybrat ...';
$string['selectuser'] = 'Vybrat  {$a}';
$string['sendlatenotifications'] = 'Zaslat oznámení hodnotitelům o pozdním odevzdání úkolu';
$string['sendlatenotifications_help'] = 'Je-li povoleno, hodnotitelé (obvykle učitelé) obdrží zprávu, kdykoli student odevzdá úkol pozdě (tj. po stanoveném termínu odevzdání). Metody zpráv jsou konfigurovatelné.';
$string['sendnotifications'] = 'Zaslat oznámení hodnotitelům o odevzdání úkolu';
$string['sendnotifications_help'] = 'Je-li povoleno, hodnotitelé (obvykle učitelé) obdrží zprávu, kdykoli student odevzdá úkol (brzy, včas i pozdě). Metody zpráv jsou konfigurovatelné.';
$string['sendstudentnotifications'] = 'Informovat studenty';
$string['sendstudentnotificationsdefault'] = 'Výchozí nastavení "Informovat studenty"';
$string['sendstudentnotificationsdefault_help'] = 'Nastavte výchozí nastavení "Informovat studenty" v zaškrtávacím poli ve známkovacím formuláři.';
$string['sendstudentnotifications_help'] = 'Je-li je povoleno, studenti obdrží upozornění o aktualizaci známky nebo komentáře.';
$string['sendsubmissionreceipts'] = 'Zaslat potvrzení o odevzdání úkolu studentům';
$string['sendsubmissionreceipts_help'] = 'Tento přepínač umožní zaslání zprávy studentům. Studenti obdrží oznámení pokaždé, když úspěšně odevzdají řešení úkolu';
$string['setmarkerallocationforlog'] = 'Nastavit přidělení hodnotitelů: (id = {$a->id}, jméno = {$a->fullname}, hodnotitel = {$a->marker}).';
$string['setmarkingallocation'] = 'Nastavit přidělení hodnotitele';
$string['setmarkingworkflowstate'] = 'Nastavení postupu známkování';
$string['setmarkingworkflowstateforlog'] = 'Nastavení postupu známkování: (id = {$a->id}, jméno = {$a->fullname}, stav = {$a->state}).';
$string['settings'] = 'Nastavení úkolu';
$string['showrecentsubmissions'] = 'Zobrazovat nedávná odevzdání';
$string['status'] = 'Stav';
$string['studentnotificationworkflowstateerror'] = 'Označení stavu pracovního postupu "Zveřejněno" musí být zasláno studentům.';
$string['submission'] = 'Odevzdané úkoly';
$string['submissioncopiedhtml'] = '<p>Vytvořili jste kopii odevzdaného úkolu <i>"{$a->assignment}".</i></p>
<p>
Stav vašeho řešení si můžete <a href="{$a->url}">prohlédnout zde</a>.</p>';
$string['submissioncopiedsmall'] = 'Zkopírovali jste předchozí odevzdaný úkol {$a->assignment}';
$string['submissioncopiedtext'] = 'Zkopírovali jste předchozí odevzdaný úkol "{$a->assignment}"

Stav odevzdaného úkolu si můžete prohlédnout:

    {$a->url}';
$string['submissiondrafts'] = 'Požadovat, aby studenti klikli na tlačítko Odeslat';
$string['submissiondrafts_help'] = 'Je-li povoleno, budou studenti muset potvrdit pomocí tlačítka Odeslat, že předložené řešení úkolu je končené. To umožňuje studentům, aby svou pracovní verzi úkolu uchovávali v systému, aniž by k ní měl učitel přístup. Pokud se nastavení změní z "Ne" na "Ano" až poté, co již někteří studenti svá řešení předložili, budou odevzdané práce považovány za konečné.';
$string['submissioneditable'] = 'Student může upravit tento úkol';
$string['submissionempty'] = 'Nic nebylo odevzdáno';
$string['submissionlog'] = 'Student: {$a->fullname}, Stav: {$a->status}';
$string['submissionmodified'] = 'Odevzdali jste řešení úkolu. Opusťte prosím tuto stránku a zkuste to znovu.';
$string['submissionmodifiedgroup'] = 'Řešení úkolu bylo někým upraveno. Opusťte prosím tuto stránku a zkuste to znovu.';
$string['submissionnotcopiedinvalidstatus'] = 'Řešení úkolu nelze zkopírovat, protože bylo novým otevřením upraveno.';
$string['submissionnoteditable'] = 'Student nemůže upravit tento úkol';
$string['submissionnotready'] = 'Tento úkol není připraven k odevzdání:';
$string['submissionplugins'] = 'Moduly odevzdání úkolu';
$string['submissionreceipthtml'] = '<p>Odeslali jste řešení úkolu "<i>{$a->assignment}</i>"</p> <p>
Stav vašeho odevzdaného úkolu <a href="{$a->url}">si můžete zobrazit</a>.</p>';
$string['submissionreceiptotherhtml'] = 'Vaše řešení úkolu "<i>{$a->assignment}</i>"  bylo odesláno.<br /><br />
Stav vašeho odevzdaného úkolu <a href="{$a->url}">si můžete zobrazit</a>.';
$string['submissionreceiptothersmall'] = 'Vaše řešení úkolu {$a->assignment} bylo odesláno.';
$string['submissionreceiptothertext'] = 'Vaše řešení úkolu "{$a->assignment}"  bylo odesláno.
Stav vašeho odevzdaného úkolu si můžete zobrazit:

{$a->url}';
$string['submissionreceipts'] = 'Odeslat potvrzení o odevzdání';
$string['submissionreceiptsmall'] = 'Odeslali jste řešení úkolu {$a->assignment}';
$string['submissionreceipttext'] = 'Odeslali jste
řešení úkolu "{$a->assignment}"

Stav vašeho odevzdaného úkolu můžete zobrazit na:

    {$a->url}';
$string['submissions'] = 'Odevzdané úkoly';
$string['submissionsclosed'] = 'Odevzdávání uzavřeno';
$string['submissionsettings'] = 'Nastavení odevzdávání úkolů';
$string['submissionslocked'] = 'V tomto úkolu nelze odevzdat práci';
$string['submissionslockedshort'] = 'Změny odevzdaných úkolů nejsou povoleny';
$string['submissionsnotgraded'] = 'Nehodnocené odpovědi: {$a}';
$string['submissionstatement'] = 'Prohlášení';
$string['submissionstatementacceptedlog'] = 'Prohlášení přijaté uživatelem {$a}';
$string['submissionstatementdefault'] = 'Prohlašuji, že jsem tento úkol vypracoval/a samostatně, s výjimkou uvedeného využití děl jiných autorů.';
$string['submissionstatement_help'] = 'Potvrzené prohlášení úkolu';
$string['submissionstatus'] = 'Stav odevzdání úkolu';
$string['submissionstatus_'] = 'Neodesláno';
$string['submissionstatus_draft'] = 'Návrh (neodesláno)';
$string['submissionstatusheading'] = 'Stav odevzdání úkolu';
$string['submissionstatus_marked'] = 'Udělena známka';
$string['submissionstatus_new'] = 'Žádné řešení úkolu';
$string['submissionstatus_reopened'] = 'Znovu otevřeno';
$string['submissionstatus_submitted'] = 'Odesláno k hodnocení';
$string['submissionsummary'] = '{$a->status}. Poslední změna {$a->timemodified}';
$string['submissionteam'] = 'Skupina';
$string['submissiontypes'] = 'Typy úkolů';
$string['submitaction'] = 'Odeslat';
$string['submitassignment'] = 'Odevzdat úkol';
$string['submitassignment_help'] = 'Po odevzdání úkolu nebudete moci provádět žádné změny.';
$string['submitforgrading'] = 'Odeslat k hodnocení';
$string['submitted'] = 'Odevzdáno';
$string['submittedearly'] = 'Úkoly byly odevzdány {$a} včas';
$string['submittedlate'] = 'Úkoly byly odevzdány {$a} po termínu';
$string['submittedlateshort'] = '{$a} po termínu';
$string['subplugintype_assignfeedback'] = 'Doplněk komentáře';
$string['subplugintype_assignfeedback_plural'] = 'Doplňky komentáře';
$string['subplugintype_assignsubmission'] = 'Doplněk řešení úkolu';
$string['subplugintype_assignsubmission_plural'] = 'Doplňky řešení úkolu';
$string['teamname'] = 'Tým: {$a}';
$string['teamsubmission'] = 'Studenti odevzdávají úkol ve skupinách';
$string['teamsubmissiongroupingid'] = 'Seskupení pro studentské skupiny';
$string['teamsubmissiongroupingid_help'] = 'Toto seskupení bude v úkolu použito k určení skupin, do kterých budou studenti rozděleni. Nezvolíte-li žádné seskupení budou studenti rozděleni do předvolených skupin všech seskupení kurzu a studenti bez skupiny budou přiřazeni do skupiny Výchozí skupina.';
$string['teamsubmission_help'] = 'Je-li povoleno, studenti budou rozděleni do skupin. Skupiny můžete zvolit z přednastavených seskupení. Pokud některý student není členem vybraného seskupení bude přiřazen do skupiny Výchozí skupina. Nezvolíte-li žádné seskupení budou studenti rozděleni do předvolených skupin všech seskupení a studenti bez skupiny budou přiřazeni do skupiny Výchozí skupina. Kterýkoli člen může za skupinu odevzdat řešení úkolu a všichni členové skupiny mohou vidět všechny provedené změny v odevzdané práci.';
$string['textinstructions'] = 'Návod k úkolu';
$string['timemodified'] = 'Naposledy změněno';
$string['timeremaining'] = 'Zbývá';
$string['timeremainingcolon'] = 'Zbývající čas: {$a}';
$string['togglezoom'] = 'Oblast přiblížít/oddálit';
$string['ungroupedusers'] = 'Nastavení "Vyžadovat zařazení do skupiny" je zapnuto a někteří uživatelé nejsou  zařazeni do skupiny, bude jim to bránit v odevzdání úkolu.';
$string['unlimitedattempts'] = 'Bez omezení';
$string['unlimitedattemptsallowed'] = 'Počet pokusů není omezen.';
$string['unlimitedpages'] = 'Bez omezení';
$string['unlocksubmissionforstudent'] = 'Povolit odevzdání studentům: (id={$a->id}, fullname={$a->fullname}).';
$string['unlocksubmissions'] = 'Odemknout odevzdané úkoly';
$string['unsavedchanges'] = 'Neuložené změny';
$string['unsavedchangesquestion'] = 'Některé změny nebyly uloženy do jednotlivých známek nebo komentářů. Chcete změny uložit a pokračovat?';
$string['updategrade'] = 'Aktualizovat hodnocení';
$string['updatetable'] = 'Uložit a aktualizovat tabulku';
$string['upgradenotimplemented'] = 'Aktualizace není implementována pro modul ({$a->type} {$a->subtype})';
$string['userextensiondate'] = 'Prodloužení poskytnuto do: {$a}';
$string['usergrade'] = 'Známka uživatele';
$string['useridlistnotcached'] = 'Změny známek nebyly uloženy, protože nebylo možné určit, pro která řešení byla.';
$string['useroverrides'] = 'Přenastavení uživatele';
$string['useroverridesdeleted'] = 'Přenastavení uživatele odtraněna';
$string['usersnone'] = 'K tomuto úkolu nemají přístup žádní studenti';
$string['userswhoneedtosubmit'] = 'Uživatelé, kteří potřebují odevzdat úkol:  {$a}';
$string['validmarkingworkflowstates'] = 'Platné stavy postupu známkování';
$string['viewadifferentattempt'] = 'Zobrazit jiný pokus';
$string['viewbatchmarkingallocation'] = 'Zobrazena stránka přidělených hodnotitelů';
$string['viewbatchsetmarkingworkflowstate'] = 'Zobrazena stránka nastavení zpracování známek';
$string['viewfeedback'] = 'Zobrazit hodnocení';
$string['viewfeedbackforuser'] = 'Zobrazit hodnocení pro uživatele: {$a}';
$string['viewfull'] = 'Kompletní zobrazení';
$string['viewfullgradingpage'] = 'Otevřít stránku pro kompletní hodnocení';
$string['viewgradebook'] = 'Zobrazit známky';
$string['viewgrading'] = 'Zobrazit všechny odevzdané úkoly';
$string['viewgradingformforstudent'] = 'Zobrazit známky studenta: (id={$a->id}, fullname={$a->fullname}).';
$string['viewownsubmissionform'] = 'Zobrazit stránku s vlastním odevzdaným úkolem.';
$string['viewownsubmissionstatus'] = 'Zobrazit stránku se stavem vlastního odevzdaného úkolu.';
$string['viewrevealidentitiesconfirm'] = 'Zobrazit stránku s potvrzením odhalené identity studentů';
$string['viewsubmission'] = 'Zobrazit odevzdané úkoly';
$string['viewsubmissionforuser'] = 'Zobrazit odevzdané úkoly uživatele: {$a}';
$string['viewsubmissiongradingtable'] = 'Zobrazit tabulku hodnocení odevzdaných úkolů.';
$string['viewsummary'] = 'Zobrazit přehled';
$string['workflowfilter'] = 'Filtr postupu';
$string['xofy'] = '{$a->x} z {$a->y}';
$string['unittestfile'] = 'testovací soubor/y';
$string['unittestfile_help'] = 'Jedná se o soubory vytvořené za účelem testování odevzdaných úkolů.';
$string['plagiarism_result'] = '<b>Výsledky: &nbsp</b> <a target="_blank" style="color: blue" href="{$a->ref}">odkaz na moss HTML výsledky</a>&nbsp[{$a->date}]';
$string['plagiarism_result_empty'] = '<b>Úkoly zatím nebyly zkontrolovány na podobnost. </b>';
$string['evaluate_all'] = 'ohodnotit všechny úkoly';
$string['plagiarism_all'] = 'zkontrolovat všechny úkoly na podobnost';