<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'assignfeedback_offline', language 'cs', branch 'MOODLE_33_STABLE'
 *
 * @package   assignfeedback_offline
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['confirmimport'] = 'Potvrdit import známek';
$string['default'] = 'Standardně povoleno';
$string['default_help'] = 'Je-li nastaveno, klasifikační archy budou nastaveny jako standardní metoda známkování pro všechny nové úkoly.';
$string['downloadgrades'] = 'Stáhnout klasifikační arch';
$string['enabled'] = 'Klasifikační arch';
$string['enabled_help'] = 'Je-li povoleno, učitel může stahovat a nahrávat klasifikační archy se známkami studentů při hodnocení úkolů.';
$string['feedbackupdate'] = 'Nastavte pole "{$a->field}" pro studenta "{$a->student}" na text "{$a->text}"';
$string['gradelockedingradebook'] = 'Známka pro {$a} byla uzamčena';
$string['graderecentlymodified'] = 'Známka pro {$a} v Moodlu je novější než známka v klasifikačním archu';
$string['gradesfile'] = 'Klasifikační arch (CSV formát)';
$string['gradesfile_help'] = 'Klasifikační arch se změněnými známkami. Tento soubor ve formátu CSV byl stažen z tohoto úkolu a musí obsahovat sloupce pro známku studenta a identifikátor. Kódování češtiny musí být UTF-8.';
$string['gradeupdate'] = 'Nastavit známku {$a->grade} pro studenta {$a->student}';
$string['ignoremodified'] = 'Povolit aktualizaci záznamů, které jsou novější v Moodlu a ne v klasifikačním archu.';
$string['ignoremodified_help'] = 'Klasifikační arch stažený z Moodlu obsahuje časový záznam o každé známce. Je-li některá známka novější na Moodlu než v klasifikačním archu, Moodle standardně odmítne její přepsání. Povolíte-li tuto možnost, bude možné novější známky v Moodlu přepsat staršími známkami z klasifikačního archu.';
$string['importgrades'] = 'Potvrdit změny v klasifikačním archu';
$string['invalidgradeimport'] = 'Moodle nemůže zpracovat nahraný klasifikační arch. Ujistěte se, že jde o formát CSV (záznamy oddělené čárkami) a zkuste to znovu.';
$string['nochanges'] = 'V klasifikačním archu nebyly nalezeny žádné změněné známky';
$string['offlinegradingworksheet'] = 'Známky';
$string['pluginname'] = 'Klasifikační arch';
$string['processgrades'] = 'Importovat známky';
$string['skiprecord'] = 'Přeskočit záznam';
$string['updatedgrades'] = 'Aktualizováno {$a} známek a zpětných vazeb';
$string['updaterecord'] = 'Aktualizovat záznam';
$string['uploadgrades'] = 'Nahrát klasifikační arch';
