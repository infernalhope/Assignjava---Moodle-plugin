<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * This file contains the definition for the library class for file submission plugin
 *
 * This class provides all the functionality for the new assignjava module.
 *
 * @package assignjavasubmission_file
 * @copyright 2012 NetSpot {@link http://www.netspot.com.au}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once($CFG->libdir.'/eventslib.php');
require_once($CFG->dirroot . '/mod/assignjava/locallib.php');
defined('MOODLE_INTERNAL') || die();


// File areas for file submission assignment.
define('ASSIGNJAVASUBMISSION_FILE_MAXSUMMARYFILES', 5);
define('ASSIGNJAVASUBMISSION_FILE_FILEAREA', 'submission_files');

/**
 * Library class for file submission plugin extending submission plugin base class
 *
 * @package   assignjavasubmission_file
 * @copyright 2012 NetSpot {@link http://www.netspot.com.au}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class assignjava_submission_file extends assignjava_submission_plugin {

    /**
     * Get the name of the file submission plugin
     * @return string
     */
    public function get_name() {
        return get_string('file', 'assignjavasubmission_file');
    }

    /**
     * Get file submission information from the database
     *
     * @param int $submissionid
     * @return mixed
     */
    private function get_file_submission($submissionid) {
        global $DB;
        return $DB->get_record('assignjavasubmission_file', array('submission'=>$submissionid));
    }

    /**
     * Get the default setting for file submission plugin
     *
     * @param MoodleQuickForm $mform The form to add elements to
     * @return void
     */
    public function get_settings(MoodleQuickForm $mform) {
        global $CFG, $COURSE;

        $defaultmaxfilesubmissions = $this->get_config('maxfilesubmissions');
        $defaultmaxsubmissionsizebytes = $this->get_config('maxsubmissionsizebytes');
        $defaultfiletypes = (string)$this->get_config('filetypeslist');

        $settings = array();
        $options = array();
        for ($i = 1; $i <= get_config('assignjavasubmission_file', 'maxfiles'); $i++) {
            $options[$i] = $i;
        }

        $name = get_string('maxfilessubmission', 'assignjavasubmission_file');
        $mform->addElement('select', 'assignjavasubmission_file_maxfiles', $name, $options);
        $mform->addHelpButton('assignjavasubmission_file_maxfiles',
                              'maxfilessubmission',
                              'assignjavasubmission_file');
        $mform->setDefault('assignjavasubmission_file_maxfiles', $defaultmaxfilesubmissions);
        $mform->disabledIf('assignjavasubmission_file_maxfiles', 'assignjavasubmission_file_enabled', 'notchecked');

        $choices = get_max_upload_sizes($CFG->maxbytes,
                                        $COURSE->maxbytes,
                                        get_config('assignjavasubmission_file', 'maxbytes'));

        $settings[] = array('type' => 'select',
                            'name' => 'maxsubmissionsizebytes',
                            'description' => get_string('maximumsubmissionsize', 'assignjavasubmission_file'),
                            'options'=> $choices,
                            'default'=> $defaultmaxsubmissionsizebytes);

        $name = get_string('maximumsubmissionsize', 'assignjavasubmission_file');
        $mform->addElement('select', 'assignjavasubmission_file_maxsizebytes', $name, $choices);
        $mform->addHelpButton('assignjavasubmission_file_maxsizebytes',
                              'maximumsubmissionsize',
                              'assignjavasubmission_file');
        $mform->setDefault('assignjavasubmission_file_maxsizebytes', $defaultmaxsubmissionsizebytes);
        $mform->disabledIf('assignjavasubmission_file_maxsizebytes',
                           'assignjavasubmission_file_enabled',
                           'notchecked');

        $name = get_string('acceptedfiletypes', 'assignjavasubmission_file');
        $mform->addElement('text', 'assignjavasubmission_file_filetypes', $name);
        $mform->addHelpButton('assignjavasubmission_file_filetypes', 'acceptedfiletypes', 'assignjavasubmission_file');
        $mform->setType('assignjavasubmission_file_filetypes', PARAM_RAW);
        $mform->setDefault('assignjavasubmission_file_filetypes', $defaultfiletypes);
        $mform->disabledIf('assignjavasubmission_file_filetypes', 'assignjavasubmission_file_enabled', 'notchecked');
        $mform->addFormRule(function ($values, $files) {
            if (empty($values['assignjavasubmission_file_filetypes'])) {
                return true;
            }
            $nonexistent = $this->get_nonexistent_file_types($values['assignjavasubmission_file_filetypes']);
            if (empty($nonexistent)) {
                return true;
            } else {
                $a = join(' ', $nonexistent);
                return ["assignjavasubmission_file_filetypes" => get_string('nonexistentfiletypes', 'assignjavasubmission_file', $a)];
            }
        });
    }

    /**
     * Save the settings for file submission plugin
     *
     * @param stdClass $data
     * @return bool
     */
    public function save_settings(stdClass $data) {
        $this->set_config('maxfilesubmissions', $data->assignjavasubmission_file_maxfiles);
        $this->set_config('maxsubmissionsizebytes', $data->assignjavasubmission_file_maxsizebytes);

        if (!empty($data->assignjavasubmission_file_filetypes)) {
            $this->set_config('filetypeslist', $data->assignjavasubmission_file_filetypes);
        } else {
            $this->set_config('filetypeslist', '');
        }

        return true;
    }

    /**
     * File format options
     *
     * @return array
     */
    private function get_file_options() {
        $fileoptions = array('subdirs' => 1,
                                'maxbytes' => $this->get_config('maxsubmissionsizebytes'),
                                'maxfiles' => $this->get_config('maxfilesubmissions'),
                                'accepted_types' => $this->get_accepted_types(),
                                'return_types' => (FILE_INTERNAL | FILE_CONTROLLED_LINK));
        if ($fileoptions['maxbytes'] == 0) {
            // Use module default.
            $fileoptions['maxbytes'] = get_config('assignjavasubmission_file', 'maxbytes');
        }
        return $fileoptions;
    }

    /**
     * Add elements to submission form
     *
     * @param mixed $submission stdClass|null
     * @param MoodleQuickForm $mform
     * @param stdClass $data
     * @return bool
     */
    public function get_form_elements($submission, MoodleQuickForm $mform, stdClass $data) {

        if ($this->get_config('maxfilesubmissions') <= 0) {
            return false;
        }

        $fileoptions = $this->get_file_options();
        $submissionid = $submission ? $submission->id : 0;

        $data = file_prepare_standard_filemanager($data,
                                                  'files',
                                                  $fileoptions,
                                                  $this->assignment->get_context(),
                                                  'assignjavasubmission_file',
                                                  ASSIGNJAVASUBMISSION_FILE_FILEAREA,
                                                  $submissionid);
        $mform->addElement('filemanager', 'files_filemanager', $this->get_name(), null, $fileoptions);

        if (!empty($this->get_config('filetypeslist'))) {
            $text = html_writer::tag('p', get_string('filesofthesetypes', 'assignjavasubmission_file'));
            $text .= html_writer::start_tag('ul');

            $typesets = $this->get_configured_typesets();
            foreach ($typesets as $type) {
                $a = new stdClass();
                $extensions = file_get_typegroup('extension', $type);
                $typetext = html_writer::tag('li', $type);
                // Only bother checking if it's a mimetype or group if it has extensions in the group.
                if (!empty($extensions)) {
                    if (strpos($type, '/') !== false) {
                        $a->name = get_mimetype_description($type);
                        $a->extlist = implode(' ', $extensions);
                        $typetext = html_writer::tag('li', get_string('filetypewithexts', 'assignjavasubmission_file', $a));
                    } else if (get_string_manager()->string_exists("group:$type", 'mimetypes')) {
                        $a->name = get_string("group:$type", 'mimetypes');
                        $a->extlist = implode(' ', $extensions);
                        $typetext = html_writer::tag('li', get_string('filetypewithexts', 'assignjavasubmission_file', $a));
                    }
                }
                $text .= $typetext;
            }

            $text .= html_writer::end_tag('ul');
            $mform->addElement('static', '', '', $text);
        }

        return true;
    }

    /**
     * Count the number of files
     *
     * @param int $submissionid
     * @param string $area
     * @return int
     */
    private function count_files($submissionid, $area) {
        $fs = get_file_storage();
        $files = $fs->get_area_files($this->assignment->get_context()->id,
                                     'assignjavasubmission_file',
                                     $area,
                                     $submissionid,
                                     'id',
                                     false);

        return count($files);
    }

    /**
     * Save the files and trigger plagiarism plugin, if enabled,
     * to scan the uploaded files via events trigger
     *
     * @param stdClass $submission
     * @param stdClass $data
     * @return bool
     */
    public function save(stdClass $submission, stdClass $data) {
        global $USER, $DB;

        $fileoptions = $this->get_file_options();

        $data = file_postupdate_standard_filemanager($data,
                                                     'files',
                                                     $fileoptions,
                                                     $this->assignment->get_context(),
                                                     'assignjavasubmission_file',
                                                     ASSIGNJAVASUBMISSION_FILE_FILEAREA,
                                                     $submission->id);

        $filesubmission = $this->get_file_submission($submission->id);

        // Plagiarism code event trigger when files are uploaded.

        $fs = get_file_storage();
        $files = $fs->get_area_files($this->assignment->get_context()->id,
                                     'assignjavasubmission_file',
                                     ASSIGNJAVASUBMISSION_FILE_FILEAREA,
                                     $submission->id,
                                     'id',
                                     false);

        $count = $this->count_files($submission->id, ASSIGNJAVASUBMISSION_FILE_FILEAREA);

        $params = array(
            'context' => context_module::instance($this->assignment->get_course_module()->id),
            'courseid' => $this->assignment->get_course()->id,
            'objectid' => $submission->id,
            'other' => array(
                'content' => '',
                'pathnamehashes' => array_keys($files)
            )
        );
        if (!empty($submission->userid) && ($submission->userid != $USER->id)) {
            $params['relateduserid'] = $submission->userid;
        }
        $event = \assignjavasubmission_file\event\assessable_uploaded::create($params);
        $event->set_legacy_files($files);
        $event->trigger();

        $groupname = null;
        $groupid = 0;
        // Get the group name as other fields are not transcribed in the logs and this information is important.
        if (empty($submission->userid) && !empty($submission->groupid)) {
            $groupname = $DB->get_field('groups', 'name', array('id' => $submission->groupid), '*', MUST_EXIST);
            $groupid = $submission->groupid;
        } else {
            $params['relateduserid'] = $submission->userid;
        }

        // Unset the objectid and other field from params for use in submission events.
        unset($params['objectid']);
        unset($params['other']);
        $params['other'] = array(
            'submissionid' => $submission->id,
            'submissionattempt' => $submission->attemptnumber,
            'submissionstatus' => $submission->status,
            'filesubmissioncount' => $count,
            'groupid' => $groupid,
            'groupname' => $groupname
        );

        if ($filesubmission) {
            $filesubmission->numfiles = $this->count_files($submission->id,
                                                           ASSIGNJAVASUBMISSION_FILE_FILEAREA);
            $updatestatus = $DB->update_record('assignjavasubmission_file', $filesubmission);
            $params['objectid'] = $filesubmission->id;

            $event = \assignjavasubmission_file\event\submission_updated::create($params);
            $event->set_assignjava($this->assignment);
            $event->trigger();
            
            //Raunigr: Pokud upraveny domaci ukol rovnou odevzdavam, ohodnotim ho
            if($submission->status === 'submitted')
            {
                $this->evaluate_homework($this->assignment, $submission); 
            }
            
            return $updatestatus;
        } else {
            $filesubmission = new stdClass();
            $filesubmission->numfiles = $this->count_files($submission->id,
                                                           ASSIGNJAVASUBMISSION_FILE_FILEAREA);
            $filesubmission->submission = $submission->id;
            $filesubmission->assignment = $this->assignment->get_instance()->id;
            $filesubmission->id = $DB->insert_record('assignjavasubmission_file', $filesubmission);
            $params['objectid'] = $filesubmission->id;

            $event = \assignjavasubmission_file\event\submission_created::create($params);
            $event->set_assignjava($this->assignment);
            $event->trigger();
            
            //Raunigr: Pokud novy domaci ukol rovnou odevzdavam, ohodnotim ho
            if($submission->status === 'submitted')
            {
                $this->evaluate_homework($this->assignment, $submission); 
            }
            
            return $filesubmission->id > 0;
        }
    }
    
    /**
     * Evaluates student's assignment. Method is called automatically during a proccess
     * of submitting assignment by student. Calling is done only if assignment 
     * has it's status changed to 'submitted'. Except from automated assessment of
     * this assignment is also created a grade and a text output saved as a
     * feedback comment.
     * Submissions's status is always changed to 'submitted' no matter what status
     * was set before the evaluation starts. If the assignment has set to automatically
     * reopen for a new attempt, the evaluation open a new attempt and actuall attempt
     * is changed to 'submitted'.
     * If any exception is raised by a JAVA code which is providing the actual evaluation
     * or is raised by student's assignment or teacher's tests, the _ErrorLog.txt
     * file is created in folder moodledata/temp/assignjava_tests/NAME_OF_ASSIGNMENT/NAME_SURNAME.
     *  
     * @param stdClass $assignment Instance of an assignment student's homework is submitted to
     * @param stdClass $submission Student's assignment to evaluate
     * @return void
     */
    public function evaluate_homework($assignment, $submission)
    {
        global $CFG;
        $fs = get_file_storage();

        //Raunigr: Kontrola, zda existuje cilova slozka
        $destination_directory = $assignment->get_context()->get_context_name(false);
        $tempDirPath = $this->get_temp_directory_path($destination_directory);

        $array = ["teacherFolderPath" => "",
                  "studentFolderPath" => "",];

        //Raunigr: Ziskani souboru s unitovymi testy
        $array["teacherFolderPath"] = $this->copy_teacher_files($tempDirPath, $fs);

        //Raunigr: Ziskani studentovych souboru
        $makeSubfolder = true;
        $array["studentFolderPath"] = $this->copy_student_files(
                                $tempDirPath, $fs, $submission, $makeSubfolder);

        $testManagerPath = $CFG->dirroot . '/mod/assignjava/submission/file/java/TestManager.jar';
        
        $args = $array["teacherFolderPath"].' '.$array["studentFolderPath"];

        //Raunigr: Spusteni me bakalarky
        
        $ini_array = parse_ini_file("submission/file/java/config.ini", true);
        $locale = $ini_array['PHP']['locale'];
        
	setlocale(LC_ALL,$locale);
	putenv('LC_ALL='.$locale);
        $java_command = 'java -jar '.$testManagerPath.' '.$args.' 2>&1';
        $output = shell_exec($java_command); 

        $this->set_grade_with_comment($assignment, $submission, $output);
        
        
        $output = '';
    }
    
    /**
     * Evaluation of all submitted homework by students in a particular assignment.
     * Evaluation is done in a same way the evaluate_homework function does.
     * Keep in mind that this proccess can takes a several minutes to complete.
     * Submissions's status is always changed to 'submitted' no matter what status
     * was set before the evaluation starts. If the assignment has set to automatically
     * reopen for a new attempt, the evaluation open a new attempt and actuall attempt
     * is changed to 'submitted'.
     * If any exception is raised by a JAVA code which is providing the actual evaluation
     * or is raised by student's assignment or teacher's tests, the _ErrorLog.txt
     * file is created in folder moodledata/temp/assignjava_tests/NAME_OF_ASSIGNMENT/NAME_SURNAME.
     *  
     * @param stdClass $assignment Instance of an assignment student's homework are being evaluated
     * @return void
     */
    public function evaluate_all_homeworks($assignment)
    {
        global $CFG;
        global $DB;
        $fs = get_file_storage();
        
        $destination_directory = $assignment->get_context()->get_context_name(false);
        $destination_directory = $destination_directory.DIRECTORY_SEPARATOR.'evaluate_all';
        $tempDirPath = $this->get_temp_directory_path($destination_directory);
        $teacher_files = $this->copy_teacher_files($tempDirPath, $fs);
        $users = array_keys($assignment->list_participants(false, true));
        
        
        foreach($users as $user_id)
        {
            $create_submission = false;
            $submission = $assignment->get_user_submission($user_id, $create_submission);
            if(!$submission)
            {
                continue;
            }
            $makeSubfolder = true;
            $student_files = $this->copy_student_files(
                    $tempDirPath, $fs, $submission, $makeSubfolder);
            
            if($teacher_files != null && $student_files != null)
            {
                $testManagerPath = $CFG->dirroot . 
                                '/mod/assignjava/submission/file/java/TestManager.jar';
                $args = $teacher_files.' '.$student_files;

                $java_command = 'java -jar '.$testManagerPath.' '.$args.' 2>&1';
                
                $ini_array = parse_ini_file("submission/file/java/config.ini", true);
                $locale = $ini_array['PHP']['locale'];
                
                setlocale(LC_ALL,$locale);
                putenv('LC_ALL='.$locale);
                $output = shell_exec($java_command); 
                
                if($submission->status != 'submitted')
                {
                    $submission->status = 'submitted';
                    $result= $DB->update_record('assignjava_submission', $submission);

                    $sourcesubmission = 
                            $this->assignment->get_user_submission($user_id, 
                                                                    false, 
                                                                    $submission->attemptnumber - 1);
                    $this->copy_submission($sourcesubmission, $submission);
                }
                
                $this->set_grade_with_comment($assignment, $submission, $output);
                
                $this->delete_teacher_zip($teacher_files);

                $output = '';
            }
        } 
    }
    
    /**
     * In a case of evaluating all students homework, teachers test files are being
     * copied to TEMP folder only once at the start. This means that folder with
     * teacher test files are not deleted at the start of evaluating a homework.
     * In situation where teacher submits a ZIP file containing the JAR file, second
     * and every other round of the evaluating would find 2 JAR files and in spite of that
     *  two sets of tests would have been done. One JAR in a ZIP and one unzipped from 
     * the previous round. To avoid this situation, plugin search in this folder for
     * ZIP file during the second and every next evaluation and delete this ZIP.
     *  
     * @param String $teacher_files Folder containing teache's test files
     * @return void
     */
    function delete_teacher_zip($teacher_files)
    {
        $files = glob($teacher_files.'*.zip');
        
        foreach($files as $file)
        {
            unlink($file);
        }
    }
    
    /**
     * Function takes all 'submitted' submissions, gather JAVA files from this
     * submissions and execute check for plagiarism which is done by MOSS. Files
     * are send to standford university server where MOSS is being executed. This
     * is done by the JAVA program MossPlagiarism.
     * The result of MOSS is an URL adress which is saved in the database and is
     * shown to a teacher right below the "check for plagiarism" button.
     *  
     * @param stdClass $assignment Instance of an assignment student's homework are being chgecked
     * @param int $assignment_id ID of the assignment
     * @return void
     */
    public function check_for_plagiarism($assignment, $assignment_id)
    {
        global $CFG;
        $fs = get_file_storage();
        
        $destination_directory = $assignment->get_context()->get_context_name(false);
        $destination_directory = $destination_directory.DIRECTORY_SEPARATOR.'plagiarism_all';
        $tempDirPath = $this->get_temp_directory_path($destination_directory);
        $tempDirPath_Files = 
                $this->get_temp_directory_path($destination_directory.DIRECTORY_SEPARATOR.'Files');
        $tempDirPath_BaseFiles = 
                $this->get_temp_directory_path($destination_directory.DIRECTORY_SEPARATOR.'BaseFile');
        
        //ziskani vsech useru, kteri jsou v kurzu zapsani
        //$currentgroup = groups_get_activity_group($this->get_course_module(), true);
        //misto false ma byt currentgroup
        $users = array_keys($assignment->list_participants(false, true));
        
        foreach($users as $user_id)
        {
            $create_submission = false;
            $submission = $assignment->get_user_submission($user_id, $create_submission);
            
            //ucitel nebo student nemuseji mit odevzdane soubory
            if($submission)
            {
                $makeSubfolder = true;
                $this->copy_student_files(
                            $tempDirPath_Files, $fs, $submission, $makeSubfolder);
            }
        } 
        
        $mossPlagiarismPath = $CFG->dirroot . 
                            '/mod/assignjava/submission/file/java/MossPlagiarism.jar';
        $args = $tempDirPath;

        $java_command = 'java -jar '.$mossPlagiarismPath.' '.$args.' 2>&1';
        
        $ini_array = parse_ini_file("submission/file/java/config.ini", true);
        $locale = $ini_array['PHP']['locale'];
        
	setlocale(LC_ALL,$locale);
	putenv('LC_ALL='.$locale);
        $output = shell_exec($java_command); 
        
        $this->deletedir($tempDirPath);
        
        $this->save_plagiarism_result($assignment_id, $output);
        
        $output;
    }
    
    /**
     * Saves the result of the proccess of checking for plagiarism in students submissions.
     *  
     * @param stdClass $assignment Instance of an assignment student's homework are being chgecked
     * @param int $assignment_id ID of the assignment
     * @return void
     */
    private function save_plagiarism_result($assignment_id, $output)
    {
        global $DB;
        
        $table = 'assignjava_plagiarism_result';
        $ref = $this->generate_plagiarism_result($output);
        
        $result = $DB->get_record($table,array('assignment'=>$assignment_id));
        
        if($result == NULL)
        {
            $result = new stdClass();
            $result->moss = (string)$ref;
            $result->assignment = (int)$assignment_id;
            $result->timestamp = time();
            $DB->insert_record($table, $result); 
        }
        else
        {
            $result->moss = $ref;
            $result->timestamp = time();
            $DB->update_record($table, $result, $bulk=false);  
        }
    }
    
    /**
     * Creates the absolute path for the provided destination directory. Destination
     * directory is created in the TEMP folder. If any of folders in path doesn't
     * exists, they are created.
     * Destination directory is then given 0777 acess rights.
     *  
     * @param String $destination_directory of an assignment student's homework are being chgecked
     * @return String - The absolute path for $destination_directory 
     */
    private function get_temp_directory_path($destination_directory)
    {
        global $CFG;
        $destination_directory = str_replace(' ', '_', $destination_directory);
        $tempDirPath = $CFG->tempdir.DIRECTORY_SEPARATOR.'assignjava_tests'.DIRECTORY_SEPARATOR.
                        $destination_directory.DIRECTORY_SEPARATOR;
        
        $access_params = 0777;
        $create_subFolders = true;
        $this->create_folder($tempDirPath, $access_params, $create_subFolders);
        
        return $tempDirPath;
    }
    
    /**
     * Deletes the provided directory. If the direcory is not empty, function
     * tries to delete the content first.
     *  
     * @param String $dir Directory to be deleted
     * @return void
     */
    public function deletedir($dir)
    {
        if (is_dir($dir))
        {
            $files = scandir($dir);
            foreach ($files as $file)
            {
                if ($file != "." && $file != "..")
                {
                    if (filetype($dir."/".$file) == "dir")
                    {
                        $this->deletedir($dir."/".$file);
                    }
                    else
                    {
                        unlink($dir."/".$file);
                    }
                }
            }
            //reset($objects);
            rmdir($dir);
        }
    }
    
    /**
     * Function takes folder path and tries to create this folder. Access rights
     * for this folder can be specified as well as a decision to create subfolders
     * or not.
     *  
     * @param String $path Path of the folder to be created
     * @param String $access_params Access rights for the folder
     * @param bool $create_subFolders If true, function will create all sub-folders
     * @return bool - Whether the folder was created or not
     */
    public function create_folder($path, $access_params, $create_subFolders)
    {
        if(!file_exists($path))
        { 
            return mkdir($path, $access_params, $create_subFolders);
        }
    }
    
    /**
     * Copying of all student files from a specific submission to the 
     * TEMP/assignjava_tests/NAME_OF_ASSIGNMENT/ folder. Function will create a 
     * folder containing the student's name as it's name.
     * Function decides what files to work with. If the submission has status 
     * 'submitted' function will copy files of this submission. If the submission 
     * has not the 'submitted', function will try to obtain files from the previous
     * submission.
     *  
     * @param String $tempDirPath Path of the TEMP folder
     * @param stdClass $fs File system
     * @param String $submission Specific submission from which function takes student files
     * @param bool $makeSubfolder If true, function will create all sub-folders
     * @return String - Path of the student's folder.
     */
    public function copy_student_files($tempDirPath, $fs, $submission, $makeSubfolder)
    {
        if($submission->status == 'reopened')
        {
            $user_id = $submission->userid;
            $previous_submission = 
                    $this->assignment->get_user_submission($user_id, false, $submission->attemptnumber - 1);
            $submission_id = $previous_submission->id;
        }
        else if($submission->status == 'new'
                || $submission->status == 'draft')
        {
            $submission_id = -1;
        }
        else
        {
            $submission_id = $submission->id;
        }
        
        if($submission_id == -1)
        {
            return null;
        }
        
        $files = $fs->get_area_files($this->assignment->get_context()->id,
                                     'assignjavasubmission_file',
                                     ASSIGNJAVASUBMISSION_FILE_FILEAREA,
                                     $submission_id,
                                     'timemodified',
                                     false);
        
        $studentFolder = null;
        $folder_checked = false;
        foreach ($files as $file) 
        { 
            if(!$makeSubfolder)
            {
                $folder_checked = true;
                $studentFolder = $tempDirPath; 
            }
            else
            {
                $studentFolder = $tempDirPath.$file->get_author();
                $studentFolder = $studentFolder.DIRECTORY_SEPARATOR;
            }
                
            $studentFolder = str_replace(' ', '_', $studentFolder);
            
            if($folder_checked == false)
            {
                if(file_exists($studentFolder))
                {
                    $this->deletedir($studentFolder);
                }
                
                if(!$this->create_folder($studentFolder, 0777, true))
                {
                    return 'Plugin nemohl vytvořit soubory/složky v TEMP složce.';
                }
                $folder_checked = true;
            }
            
            
            $file_name = substr($file->get_filename(),0,-4);
            $fileExtension = substr($file->get_filename(),-4);

            $path = $studentFolder.$file_name.$fileExtension;
            $file->copy_content_to($path);
        }
        
        return $studentFolder;
    }
    
    /**
     * Copying of all teacher test files provided by a teacher in the settings section
     * for the particular assignjava instance. Function will create a foled for
     * these teacher test files in folder TEMP/assignjava_tests/NAME_OF_ASSIGNMENT/
     * and also sub-folders if required.
     *  
     * @param String $tempDirPath Path of the TEMP folder
     * @param stdClass $fs File system
     * @return String - Path of the teacher's folder.
     */
    public function copy_teacher_files($tempDirPath, $fs)
    {
        if ($files_UT = $fs->get_area_files($this->assignment->get_context()->id, 
                                             'mod_assignjava', 
                                             ASSIGNJAVA_UNITTESTFILE_FILEAREA,
                                             0, 
                                             'timemodified', 
                                             false)) 
        { 
            $folder_checked = false;
            foreach ($files_UT as $file) 
            {
                
                $teacherFolder = $tempDirPath.'Unit_tests'.DIRECTORY_SEPARATOR;

                if($folder_checked == false)
                {
                    if(file_exists($teacherFolder))
                    {
                        $this->deletedir($teacherFolder);
                    }
                    if(!$this->create_folder($teacherFolder, 0777, true))
                    {
                        return 'Plugin nemohl vytvořit soubory/složky v TEMP složce.'; 
                    }
                    $folder_checked = true;
                } 

                $file_name = substr($file->get_filename(),0,-4);
                $fileExtension = substr($file->get_filename(),-4);

                $path = $teacherFolder.$file_name.$fileExtension;
                $file->copy_content_to($path);
            }  
        }
        
        return $teacherFolder;
    }
    
    /**
     * Creates a grade and a text feedback based on the result of the evaluation
     * of a student's homework.
     *  
     * @param stdClass $assignment Instance of an assignment student's homework was being chgecked
     * @param stdClass $submission Student's assignment instance
     * @param String $$output The result of the evaluation of student's homework
     * @return void
     */
    private function set_grade_with_comment($assignment, $submission, $output)
    {
        $result = $this->generate_result($output);

        $attemptnumber = $submission->attemptnumber;
        $grade = $assignment->get_user_grade($submission->userid, true, $attemptnumber);
        
        $grade_item = $assignment->get_grade_item();
        $grade_min = $grade_item->grademin;
        $grade_max = $grade_item->grademax;
        
        
        //nastaveni grade
        $grade->feedbacktext = 'Výsledek hodnocení úkolu: <br/>'.$result;
        $grade->feedbackformat = FORMAT_HTML;
        $grade->assignjavafeedbackcomments_editor['text'] = $grade->feedbacktext;
        $grade->assignjavafeedbackcomments_editor['format'] = $grade->feedbackformat;
        $grade->grade = $grade_min; 
        if($this->generate_grade($output)) $grade->grade = $grade_max; 

        if($assignment->get_instance()->attemptreopenmethod == ASSIGNJAVA_ATTEMPT_REOPEN_METHOD_UNTILPASS)
        {
            $reopenattempt = true;
        }
        else
        {
            $reopenattempt = false;
        }

        $grade_updated = $assignment->save_grade_teacher($submission->userid, $grade);
        
        $result = null;
    }
    
    /**
     * Parses and modifies the resulf of MOSS to fit the needs of the database table this 
     * result is saved in.
     *  
     * @param String $$output The result of the MOSS check for plagiarism
     * @return String - modified result
     */
    private function generate_plagiarism_result($output)
    {
        $plagiarism_prefix = '[OUTPUT]';
        $plagiarism_prefix_length = strlen($plagiarism_prefix) + 1;
        $start_index = strrpos($output, $plagiarism_prefix);
        $end_index = strlen($output);
        
        $text = substr($output, $plagiarism_prefix_length);
        
        return $text;
    }
    
    /**
     * Parses and modifies the resulf of the evaluation of a student's homework to 
     * the form of a table. This table is shown as a text feedback.
     *  
     * @param String $$output The result of the MOSS check for plagiarism
     * @return String - modified result
     */
    private function generate_result($output)
    {
        $evaluation_prefix = '[EVALUATION_START]';
        $evaluation_prefix_length = strlen($evaluation_prefix) + 1;
        $start_index = strrpos($output, $evaluation_prefix);
        
        $report_prefix = '[REPORT_START]';
        $end_index = strrpos($output, $report_prefix);
        
        $length = ($end_index - 1) - ($start_index + $evaluation_prefix_length);
        
        $text = substr($output, ($start_index + $evaluation_prefix_length), $length);
        $ret = iconv(mb_detect_encoding($text, mb_detect_order(), true), "UTF-8", $text);
        $name = substr($ret, 0, strpos($ret, ','));
        
        $ret = $this->create_result_table($ret);
        
        
        return $ret;
    }
    
    /**
     * Creates the result table for the function generate_result.
     *  
     * @param String $text Parsed and modified output
     * @return String - modified result
     */
    private function create_result_table($text)
    {
        $table_head =  '<br>
                        <table style="width:100%">
                        <tr>
                          <th><b>studentova metoda/třída</b></th>
                          <th><b>test metoda</b></th>
                          <th><b>výsledek</b></th>
                          <th><b>zpráva</b></th>
                        </tr>';
        
        $end_loop = false;
        $text_end = false;
        $table_body = '';
        while($end_loop != true)
        {
            $row_start = '<tr>';
            $test_method = strstr($text, ',', true);
            
            $text = substr($text, strlen($test_method) + 1);
            $student_method = strstr($text, ',', true);
            
            $text = substr($text, strlen($student_method) + 1);
            $result = strstr($text, ',', true);
            
            $text = substr($text, strlen($result) + 1);
            $note = strstr($text, "\n", true);
            
            if($note == false)
            {
                if(substr_count($text, "\n") == 0)
                {
                    $note = $text;
                    $text_end = true;
                }
            }
            
            
            
            $row_end = '</tr>';
            
            $table_body = $table_body
                            .$row_start
                                .'<td>'.$test_method.'</td>'
                                .'<td>'.$student_method.'</td>'
                                .'<td>'.$result.'</td>'
                                .'<td>'.$note.'</td>'
                            .$row_end;

            if(!strstr($text, ',', true) || $text_end)
            {
                $end_loop = true;
            }
            else
            {
                $text = substr($text, strlen($note) + 1);
            }
        }
        
        $table_end = '</table>';
        
        return $table_head.$table_body.$table_end;
    }
    
    /**
     * Parses the provided output of the evaluation of a student's homework
     * and search for the overall result. This result can be 'OK' or 'FAIL'. Based
     * on this result is decided what grade is given to the submission.
     *  
     * @param String $text Parsed and modified output
     * @return String - modified result
     */
    private function generate_grade($result)
    {
        $report_prefix = '[REPORT_START]';
        $report_prefix_length = strlen($report_prefix) + 1;
        
        $index = strrpos($result, $report_prefix);
        $temp = substr($result,($index + $report_prefix_length), strlen($result));
        
        return strpos($temp, 'OK');
    }

    /**
     * Produce a list of files suitable for export that represent this feedback or submission
     *
     * @param stdClass $submission The submission
     * @param stdClass $user The user record - unused
     * @return array - return an array of files indexed by filename
     */
    public function get_files(stdClass $submission, stdClass $user) {
        $result = array();
        $fs = get_file_storage();

        $files = $fs->get_area_files($this->assignment->get_context()->id,
                                     'assignjavasubmission_file',
                                     ASSIGNJAVASUBMISSION_FILE_FILEAREA,
                                     $submission->id,
                                     'timemodified',
                                     false);

        foreach ($files as $file) {
            // Do we return the full folder path or just the file name?
            if (isset($submission->exportfullpath) && $submission->exportfullpath == false) {
                $result[$file->get_filename()] = $file;
            } else {
                $result[$file->get_filepath().$file->get_filename()] = $file;
            }
        }
        return $result;
    }

    /**
     * Display the list of files  in the submission status table
     *
     * @param stdClass $submission
     * @param bool $showviewlink Set this to true if the list of files is long
     * @return string
     */
    public function view_summary(stdClass $submission, & $showviewlink) {
        $count = $this->count_files($submission->id, ASSIGNJAVASUBMISSION_FILE_FILEAREA);

        // Show we show a link to view all files for this plugin?
        $showviewlink = $count > ASSIGNJAVASUBMISSION_FILE_MAXSUMMARYFILES;
        if ($count <= ASSIGNJAVASUBMISSION_FILE_MAXSUMMARYFILES) {
            return $this->assignment->render_area_files('assignjavasubmission_file',
                                                        ASSIGNJAVASUBMISSION_FILE_FILEAREA,
                                                        $submission->id);
        } else {
            return get_string('countfiles', 'assignjavasubmission_file', $count);
        }
    }

    /**
     * No full submission view - the summary contains the list of files and that is the whole submission
     *
     * @param stdClass $submission
     * @return string
     */
    public function view(stdClass $submission) {
        return $this->assignment->render_area_files('assignjavasubmission_file',
                                                    ASSIGNJAVASUBMISSION_FILE_FILEAREA,
                                                    $submission->id);
    }



    /**
     * Return true if this plugin can upgrade an old Moodle 2.2 assignment of this type
     * and version.
     *
     * @param string $type
     * @param int $version
     * @return bool True if upgrade is possible
     */
    public function can_upgrade($type, $version) {

        $uploadsingletype ='uploadsingle';
        $uploadtype ='upload';

        if (($type == $uploadsingletype || $type == $uploadtype) && $version >= 2011112900) {
            return true;
        }
        return false;
    }


    /**
     * Upgrade the settings from the old assignment
     * to the new plugin based one
     *
     * @param context $oldcontext - the old assignment context
     * @param stdClass $oldassignment - the old assignment data record
     * @param string $log record log events here
     * @return bool Was it a success? (false will trigger rollback)
     */
    public function upgrade_settings(context $oldcontext, stdClass $oldassignment, & $log) {
        global $DB;

        if ($oldassignment->assignmenttype == 'uploadsingle') {
            $this->set_config('maxfilesubmissions', 1);
            $this->set_config('maxsubmissionsizebytes', $oldassignment->maxbytes);
            return true;
        } else if ($oldassignment->assignmenttype == 'upload') {
            $this->set_config('maxfilesubmissions', $oldassignment->var1);
            $this->set_config('maxsubmissionsizebytes', $oldassignment->maxbytes);

            // Advanced file upload uses a different setting to do the same thing.
            $DB->set_field('assignjava',
                           'submissiondrafts',
                           $oldassignment->var4,
                           array('id'=>$this->assignment->get_instance()->id));

            // Convert advanced file upload "hide description before due date" setting.
            $alwaysshow = 0;
            if (!$oldassignment->var3) {
                $alwaysshow = 1;
            }
            $DB->set_field('assignjava',
                           'alwaysshowdescription',
                           $alwaysshow,
                           array('id'=>$this->assignment->get_instance()->id));
            return true;
        }
    }

    /**
     * Upgrade the submission from the old assignment to the new one
     *
     * @param context $oldcontext The context of the old assignment
     * @param stdClass $oldassignment The data record for the old oldassignment
     * @param stdClass $oldsubmission The data record for the old submission
     * @param stdClass $submission The data record for the new submission
     * @param string $log Record upgrade messages in the log
     * @return bool true or false - false will trigger a rollback
     */
    public function upgrade(context $oldcontext,
                            stdClass $oldassignment,
                            stdClass $oldsubmission,
                            stdClass $submission,
                            & $log) {
        global $DB;

        $filesubmission = new stdClass();

        $filesubmission->numfiles = $oldsubmission->numfiles;
        $filesubmission->submission = $submission->id;
        $filesubmission->assignment = $this->assignment->get_instance()->id;

        if (!$DB->insert_record('assignjavasubmission_file', $filesubmission) > 0) {
            $log .= get_string('couldnotconvertsubmission', 'mod_assignjava', $submission->userid);
            return false;
        }

        // Now copy the area files.
        $this->assignment->copy_area_files_for_upgrade($oldcontext->id,
                                                        'mod_assignment',
                                                        'submission',
                                                        $oldsubmission->id,
                                                        $this->assignment->get_context()->id,
                                                        'assignjavasubmission_file',
                                                        ASSIGNJAVASUBMISSION_FILE_FILEAREA,
                                                        $submission->id);

        return true;
    }

    /**
     * The assignment has been deleted - cleanup
     *
     * @return bool
     */
    public function delete_instance() {
        global $DB;
        // Will throw exception on failure.
        $DB->delete_records('assignjavasubmission_file',
                            array('assignment'=>$this->assignment->get_instance()->id));

        return true;
    }

    /**
     * Formatting for log info
     *
     * @param stdClass $submission The submission
     * @return string
     */
    public function format_for_log(stdClass $submission) {
        // Format the info for each submission plugin (will be added to log).
        $filecount = $this->count_files($submission->id, ASSIGNJAVASUBMISSION_FILE_FILEAREA);

        return get_string('numfilesforlog', 'assignjavasubmission_file', $filecount);
    }

    /**
     * Return true if there are no submission files
     * @param stdClass $submission
     */
    public function is_empty(stdClass $submission) {
        return $this->count_files($submission->id, ASSIGNJAVASUBMISSION_FILE_FILEAREA) == 0;
    }

    /**
     * Determine if a submission is empty
     *
     * This is distinct from is_empty in that it is intended to be used to
     * determine if a submission made before saving is empty.
     *
     * @param stdClass $data The submission data
     * @return bool
     */
    public function submission_is_empty(stdClass $data) {
        $files = file_get_drafarea_files($data->files_filemanager);
        return count($files->list) == 0;
    }

    /**
     * Get file areas returns a list of areas this plugin stores files
     * @return array - An array of fileareas (keys) and descriptions (values)
     */
    public function get_file_areas() {
        return array(ASSIGNJAVASUBMISSION_FILE_FILEAREA=>$this->get_name());
    }

    /**
     * Copy the student's submission from a previous submission. Used when a student opts to base their resubmission
     * on the last submission.
     * @param stdClass $sourcesubmission
     * @param stdClass $destsubmission
     */
    public function copy_submission(stdClass $sourcesubmission, stdClass $destsubmission) {
        global $DB;

        // Copy the files across.
        $contextid = $this->assignment->get_context()->id;
        $fs = get_file_storage();
        $files = $fs->get_area_files($contextid,
                                     'assignjavasubmission_file',
                                     ASSIGNJAVASUBMISSION_FILE_FILEAREA,
                                     $sourcesubmission->id,
                                     'id',
                                     false);
        foreach ($files as $file) {
            $fieldupdates = array('itemid' => $destsubmission->id);
            $fs->create_file_from_storedfile($fieldupdates, $file);
        }

        // Copy the assignjavasubmission_file record.
        if ($filesubmission = $this->get_file_submission($sourcesubmission->id)) {
            unset($filesubmission->id);
            $filesubmission->submission = $destsubmission->id;
            $DB->insert_record('assignjavasubmission_file', $filesubmission);
        }
        return true;
    }

    /**
     * Return a description of external params suitable for uploading a file submission from a webservice.
     *
     * @return external_description|null
     */
    public function get_external_parameters() {
        return array(
            'files_filemanager' => new external_value(
                PARAM_INT,
                'The id of a draft area containing files for this submission.',
                VALUE_OPTIONAL
            )
        );
    }

    /**
     * Return the plugin configs for external functions.
     *
     * @return array the list of settings
     * @since Moodle 3.2
     */
    public function get_config_for_external() {
        global $CFG;

        $configs = $this->get_config();

        // Get a size in bytes.
        if ($configs->maxsubmissionsizebytes == 0) {
            $configs->maxsubmissionsizebytes = get_max_upload_file_size($CFG->maxbytes, $this->assignment->get_course()->maxbytes,
                                                                        get_config('assignjavasubmission_file', 'maxbytes'));
        }
        return (array) $configs;
    }

    /**
     * Get the type sets configured for this assignment.
     *
     * @return array('groupname', 'mime/type', ...)
     */
    private function get_configured_typesets() {
        $typeslist = (string)$this->get_config('filetypeslist');

        $sets = $this->get_typesets($typeslist);

        return $sets;
    }

    /**
     * Get the type sets passed.
     *
     * @param string $types The space , ; separated list of types
     * @return array('groupname', 'mime/type', ...)
     */
    private function get_typesets($types) {
        $sets = array();
        if (!empty($types)) {
            $sets = preg_split('/[\s,;:"\']+/', $types, null, PREG_SPLIT_NO_EMPTY);
        }
        return $sets;
    }


    /**
     * Return the accepted types list for the file manager component.
     *
     * @return array|string
     */
    private function get_accepted_types() {
        $acceptedtypes = $this->get_configured_typesets();

        if (!empty($acceptedtypes)) {
            return $acceptedtypes;
        }

        return '*';
    }

    /**
     * List the nonexistent file types that need to be removed.
     *
     * @param string $types space , or ; separated types
     * @return array A list of the nonexistent file types.
     */
    private function get_nonexistent_file_types($types) {
        $nonexistent = [];
        foreach ($this->get_typesets($types) as $type) {
            // If there's no extensions under that group, it doesn't exist.
            $extensions = file_get_typegroup('extension', [$type]);
            if (empty($extensions)) {
                $nonexistent[$type] = true;
            }
        }
        return array_keys($nonexistent);
    }
}
